const express = require("express");
const cors = require("cors");
const http = require("http");
const path = require("path");
const crypto = require("crypto");
const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");
const dotenv = require("dotenv");
const { Server } = require("socket.io");
const { sendWhatsAppText } = require("./whatsappService");
const { HELP_PROBLEMS, normalizeHelpSubmission, normalizeHelpStatus } = require("./help-center");
const { normalizeCashPlanActivation } = require("./cash-plan");

dotenv.config({ path: path.join(__dirname, ".env") });
dotenv.config();

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
const PORT = Number(process.env.PORT || 5000);
const DB_NAME = process.env.MONGODB_DB_NAME || "axzen_canteen";
const INDIA_TZ = "Asia/Kolkata";
const VERIFY_TOKEN = process.env.VERIFY_TOKEN;
const DEFAULT_CANTEEN_ID = "AXC-0001";
const DEFAULT_ADMIN_PASSWORD = "Axzen@123";
const CANTEEN_ROLES = ["admin", "user", "cashier", "store_keeper", "manager", "accountant", "chef", "waiter", "billing", "inventory"];
const SALES_CONTACT_PHONE = "8790568446";
const SALES_WEBSITE = "www.axzeninfotech.com";
const TRIAL_EXPIRED_MESSAGE = `Trial expired. Please contact our sales team at ${SALES_CONTACT_PHONE}. For more details, visit ${SALES_WEBSITE}.`;
const CASHFREE_ENV = String(process.env.CASHFREE_ENV || "sandbox").toLowerCase() === "production" ? "production" : "sandbox";
const CASHFREE_API_VERSION = process.env.CASHFREE_API_VERSION || "2025-01-01";
const CASHFREE_API_BASE = CASHFREE_ENV === "production" ? "https://api.cashfree.com/pg" : "https://sandbox.cashfree.com/pg";

// Warn during startup when the Meta webhook verification token is not configured.
if (!VERIFY_TOKEN) {
  console.warn("VERIFY_TOKEN is missing. Meta WhatsApp webhook verification will fail until it is configured.");
}

app.use(cors());
require("./catalog-import").register(app, requireAdmin);

app.use(express.json({
  limit: "8mb",
  verify: (req, res, buf) => {
    req.rawBody = buf.toString("utf8");
  }
}));

// Safely handle malformed JSON bodies without crashing existing API routes.
app.use((error, req, res, next) => {
  if (error instanceof SyntaxError && error.status === 400 && "body" in error) {
    console.warn("Invalid JSON request body:", error.message);
    return res.status(400).json({ success: false, message: "Invalid JSON body" });
  }
  return next(error);
});

const staticPageOptions = {
  setHeaders(res, filePath) {
    if (filePath.endsWith(".html")) {
      res.setHeader("Cache-Control", "no-store, max-age=0");
    }
  }
};

app.use("/mobile", express.static(path.join(__dirname, "../sa"), staticPageOptions));
app.use("/partner", express.static(path.join(__dirname, "../sa"), staticPageOptions));
app.use("/admin", express.static(path.join(__dirname, "../admin-web"), staticPageOptions));
app.use("/sales", express.static(path.join(__dirname, "../marketing-web"), staticPageOptions));
app.use("/marketing", express.static(path.join(__dirname, "../marketing-web"), staticPageOptions));
app.use("/employee", express.static(path.join(__dirname, "../employee-web"), staticPageOptions));
app.use("/manager", express.static(path.join(__dirname, "../employee-web"), staticPageOptions));

const defaultMenuItems = [
  { id: 1, name: "Tea", price: 10, category: "Tea", image: "https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=500&q=80" },
  { id: 2, name: "Coffee", price: 20, category: "Tea", image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=500&q=80" },
  { id: 3, name: "Meals", price: 80, category: "Meals", image: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=500&q=80" },
  { id: 4, name: "Idly", price: 30, category: "Tiffin", image: "https://images.unsplash.com/photo-1630409351241-e90e7f5e434d?auto=format&fit=crop&w=500&q=80", subItems: [{ name: "Single", price: 15 }, { name: "Half Plate", price: 30 }, { name: "Full Plate", price: 50 }] },
  { id: 5, name: "Dosa", price: 45, category: "Tiffin", image: "https://images.unsplash.com/photo-1668236543090-82eba5ee5976?auto=format&fit=crop&w=500&q=80" },
  { id: 6, name: "Samosa", price: 15, category: "Snacks", image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=500&q=80" },
  { id: 7, name: "Veg Puff", price: 25, category: "Snacks", image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=500&q=80" },
  { id: 8, name: "Juice", price: 35, category: "Juice", image: "https://images.unsplash.com/photo-1622597467836-f3285f2131b8?auto=format&fit=crop&w=500&q=80" },
  { id: 9, name: "Chicken", price: 340, category: "Chicken Center", billingType: "weight", image: "https://images.unsplash.com/photo-1604503468506-a8da13d82791?auto=format&fit=crop&w=500&q=80", subItems: [{ name: "Curry Cut", price: 340 }, { name: "Boneless", price: 420 }, { name: "Leg Piece", price: 360 }] },
  { id: 10, name: "Mutton", price: 780, category: "Chicken Center", billingType: "weight", image: "https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?auto=format&fit=crop&w=500&q=80", subItems: [{ name: "Curry Cut", price: 780 }, { name: "Keema", price: 820 }, { name: "Bone", price: 650 }] }
];

const defaultCatalogItems = [
  ...defaultMenuItems,
  { id: 101, name: "Poori", price: 40, category: "Tiffin", image: "https://images.unsplash.com/photo-1617692855027-33b14f061079?auto=format&fit=crop&w=500&q=80" },
  { id: 102, name: "Vada", price: 25, category: "Tiffin", image: "https://images.unsplash.com/photo-1606491956689-2ea866880c84?auto=format&fit=crop&w=500&q=80" },
  { id: 103, name: "Chapati", price: 50, category: "Meals", image: "https://images.unsplash.com/photo-1601050690117-94f5f6fa8bd7?auto=format&fit=crop&w=500&q=80" },
  { id: 104, name: "Lemon Rice", price: 45, category: "Lunch", image: "https://images.unsplash.com/photo-1596797038530-2c107229654b?auto=format&fit=crop&w=500&q=80" },
  { id: 105, name: "Curd Rice", price: 40, category: "Lunch", image: "https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?auto=format&fit=crop&w=500&q=80" },
  { id: 106, name: "Water Bottle", price: 20, category: "Drinks", image: "https://images.unsplash.com/photo-1550505095-81378a674395?auto=format&fit=crop&w=500&q=80" },
  { id: 107, name: "Biscuits", price: 10, category: "Snacks", image: "https://images.unsplash.com/photo-1558961363-fa8fdf82db35?auto=format&fit=crop&w=500&q=80" },
  { id: 108, name: "Banana", price: 10, category: "Snacks", image: "https://images.unsplash.com/photo-1603833665858-e61d17a86224?auto=format&fit=crop&w=500&q=80" },
  { id: 201, name: "Chicken Curry Cut", price: 240, category: "Chicken", billingType: "weight" },
  { id: 202, name: "Chicken Fry Pieces", price: 260, category: "Chicken", billingType: "weight" },
  { id: 203, name: "Boneless Chicken", price: 320, category: "Chicken", billingType: "weight" },
  { id: 204, name: "Chicken Leg Pieces", price: 280, category: "Chicken", billingType: "weight" },
  { id: 205, name: "Chicken Wings", price: 220, category: "Chicken", billingType: "weight" },
  { id: 206, name: "Chicken Liver", price: 180, category: "Chicken", billingType: "weight" },
  { id: 207, name: "Mutton Curry Cut", price: 780, category: "Chicken", billingType: "weight" },
  { id: 208, name: "Mutton Keema", price: 820, category: "Chicken", billingType: "weight" },
  { id: 209, name: "Eggs", price: 6, category: "Chicken", unit: "Pieces" }
];

const defaultStockItems = [
  { id: 1, item: "Tea Powder", stock: 0.5, unit: "Kg", minStock: 1 },
  { id: 2, item: "Sugar", stock: 1.2, unit: "Kg", minStock: 2 },
  { id: 3, item: "Milk", stock: 0.8, unit: "Ltr", minStock: 2 },
  { id: 4, item: "Bread", stock: 12, unit: "Packet", minStock: 5 }
];

const defaultUsers = [
  { id: 1, name: "Admin", mobile: "admin", password: "1234", role: "admin", active: true },
  { id: 2, name: "Cashier", mobile: "user", password: "1234", role: "user", active: true }
];

const defaultSettings = {
  key: "app",
  canteenName: "Main Canteen",
  brandName: "axzen",
  tagline: "Infotech",
  logoUrl: "",
  receiptLogoPosition: "above",
  receiptLogoSize: 100,
  receiptArea: "",
  menuLanguage: "english",
  receiptLanguage: "english",
  businessCategory: "Canteen",
  posMode: "canteen",
  reportTime: "22:00",
  adminWhatsAppNumber: "",
  reportPhone: "",
  autoReport: false,
  reportType: "daily"
};

const defaultMarketingUsers = [
  { employeeId: "MKT001", name: "Venkatesh", password: "1234", role: "marketing", active: true, target: 20 },
  { employeeId: "MKT002", name: "Sravani", password: "1234", role: "marketing", active: true, target: 18 },
  { employeeId: "SUPER", name: "Super Admin", password: "admin123", role: "super_admin", active: true, target: 0 }
];

const defaultMarketingCanteens = [
  {
    id: 1001,
    canteenName: "Sri Lakshmi Foods",
    businessCategory: "Canteen",
    ownerName: "Ramesh Kumar",
    ownerMobile: "9876543210",
    alternateMobile: "9876500001",
    address: "Madhapur Main Road",
    city: "Hyderabad",
    state: "Telangana",
    counters: 2,
    printersRequired: 2,
    selectedPlan: "Professional",
    planType: "Paid",
    planStartDate: new Date().toISOString().slice(0, 10),
    planExpiryDate: new Date(Date.now() + 365 * 86400000).toISOString().slice(0, 10),
    paymentMode: "UPI",
    paidAmount: 12000,
    pendingAmount: 3000,
    notes: "Needs two thermal printers and menu setup.",
    documents: "trade-license.jpg",
    status: "Pending Approval",
    online: true,
    submittedBy: "MKT001",
    submittedByName: "Venkatesh",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 1002,
    canteenName: "Metro Staff Canteen",
    businessCategory: "Canteen",
    ownerName: "Kiran",
    ownerMobile: "9000011111",
    alternateMobile: "",
    address: "Industrial Area",
    city: "Vijayawada",
    state: "Andhra Pradesh",
    counters: 4,
    printersRequired: 4,
    selectedPlan: "Enterprise",
    planType: "Paid",
    planStartDate: new Date(Date.now() - 20 * 86400000).toISOString().slice(0, 10),
    planExpiryDate: new Date(Date.now() + 345 * 86400000).toISOString().slice(0, 10),
    paymentMode: "Bank Transfer",
    paidAmount: 30000,
    pendingAmount: 0,
    notes: "Approved pilot customer.",
    documents: "agreement.pdf",
    status: "Active",
    online: true,
    activatedCanteenId: "AXC-1002",
    canteenLoginId: "AXC1002",
    defaultPassword: "AXZEN1002",
    submittedBy: "MKT002",
    submittedByName: "Sravani",
    approvedBy: "SUPER",
    approvedAt: new Date(Date.now() - 18 * 86400000).toISOString(),
    createdAt: new Date(Date.now() - 20 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 18 * 86400000).toISOString()
  }
];

const defaultMarketingPayments = defaultMarketingCanteens
  .filter(item => Number(item.paidAmount || 0) > 0)
  .map(item => ({
    id: item.id,
    canteenId: item.id,
    canteenName: item.canteenName,
    amount: Number(item.paidAmount || 0),
    pendingAmount: Number(item.pendingAmount || 0),
    paymentMode: item.paymentMode,
    collectedBy: item.submittedBy,
    collectedByName: item.submittedByName,
    createdAt: item.createdAt,
    updatedAt: item.updatedAt
  }));

const defaultMarketingSupportTickets = [
  { id: 1, title: "Printer pairing help", status: "Open", canteenName: "Metro Staff Canteen", priority: "High", createdAt: new Date(Date.now() - 2 * 86400000).toISOString() },
  { id: 2, title: "Plan upgrade request", status: "Open", canteenName: "Sri Lakshmi Foods", priority: "Medium", createdAt: new Date().toISOString() }
];

const defaultWebsitePlans = [
  {
    id: 1,
    name: "Starter",
    description: "For small businesses starting with smart digital billing.",
    originalPrice: "2000",
    offerPrice: "599",
    billingCycle: "month",
    badge: "Special Offer",
    cta: "Choose Starter",
    popular: false,
    active: true,
    sortOrder: 1,
    features: ["Fast POS Billing", "Product Management", "Basic Inventory", "Daily Sales Reports", "Customer Management", "1 Billing User", "Thermal Printer Support", "Cloud Data Backup"]
  },
  {
    id: 2,
    name: "Growth",
    description: "For growing businesses that need better control and insights.",
    originalPrice: "2500",
    offerPrice: "799",
    billingCycle: "month",
    badge: "Most Popular",
    cta: "Choose Growth",
    popular: true,
    active: true,
    sortOrder: 2,
    features: ["Everything in Starter", "Advanced Sales Reports", "Expense Management", "Multi-User Access", "Customer Purchase History", "Low Stock Alerts", "Cloud Backup", "Priority Support"]
  },
  {
    id: 3,
    name: "Professional",
    description: "For established businesses that want powerful operations.",
    originalPrice: "3000",
    offerPrice: "999",
    billingCycle: "month",
    badge: "Special Offer",
    cta: "Choose Professional",
    popular: false,
    active: true,
    sortOrder: 3,
    features: ["Everything in Growth", "Unlimited Billing Users", "Advanced Analytics", "Profit & Loss Reports", "Multiple Printer Support", "Advanced Inventory", "Data Export", "Premium Support"]
  },
  {
    id: 4,
    name: "Business",
    description: "For multi-branch businesses and growing enterprises.",
    originalPrice: "",
    offerPrice: "Custom Pricing",
    billingCycle: "",
    badge: "Tailored Solution",
    cta: "Contact Sales Team",
    popular: false,
    active: true,
    sortOrder: 4,
    features: ["Unlimited Users", "Multi-Branch Management", "Centralized Dashboard", "Advanced Business Analytics", "Dedicated Account Manager", "Custom Integrations", "Priority Support", "Business Solutions"]
  }
];

let mongoReady = false;
let mongoError = "";
let initialized = false;
let schedulerStarted = false;
let lastScheduledReportKey = "";

let memory = {
  canteens: [{
    canteenId: DEFAULT_CANTEEN_ID,
    name: "Main Canteen",
    ownerName: "Admin",
    phone: "admin",
    address: "",
    plan: "default",
    paymentStatus: "paid",
    active: true
  }],
  printers: [],
  menuItems: [...defaultMenuItems],
  stockItems: [...defaultStockItems],
  stockUsage: [],
  branchAddresses: [],
  creditors: [],
  expenses: [],
  orders: [],
  sales: [],
  users: [...defaultUsers],
  settings: { ...defaultSettings },
  whatsappLogs: [],
  marketingUsers: [...defaultMarketingUsers],
  marketingCanteens: [...defaultMarketingCanteens],
  marketingActivities: [
    { id: 1, type: "approved", text: "Metro Staff Canteen approved by Super Admin", actor: "Super Admin", createdAt: new Date(Date.now() - 18 * 86400000).toISOString() },
    { id: 2, type: "created", text: "Sri Lakshmi Foods submitted for approval", actor: "Venkatesh", createdAt: new Date().toISOString() }
  ],
  marketingPayments: [...defaultMarketingPayments],
  supportTickets: [...defaultMarketingSupportTickets],
  enquiries: [],
  websitePlans: [...defaultWebsitePlans],
  subscriptionOrders: [],
  globalCatalogItems: defaultCatalogItems.map(item => ({ catalogId: item.id, name: item.name, image: item.image || "", sourceCount: 1 }))
};

const BillTaxes = require('../sa/bill-taxes');
const orderSchema = new mongoose.Schema({
  taxes:[mongoose.Schema.Types.Mixed], charges:[mongoose.Schema.Types.Mixed], taxTotal:Number, taxableAmount:Number, taxSettings:mongoose.Schema.Types.Mixed, gstin:String, receiptFields:mongoose.Schema.Types.Mixed,
  orderType: String, tableId: String, tableName: String, dineSessionId: String,
  kitchenTickets: [mongoose.Schema.Types.Mixed],
  canteenId: { type: String, index: true, default: DEFAULT_CANTEEN_ID },
  id: { type: Number, index: true },
  clientOrderId: { type: String, sparse: true, index: true },
  time: String,
  canteen: String,
  cashier: String,
  cashierMobile: String,
  branchAddress: String,
  payment: String,
  paymentBreakup: mongoose.Schema.Types.Mixed,
  creditName: String,
  subtotal: Number,
  discount: Number,
  total: Number,
  items: [{ id: Number, lineId: String, parentId: Number, name: String, nameTe: String, printName: String, optionName: String, price: Number, qty: Number, billingType: String, grams: Number, ratePerKg: Number, lineTotal: Number }],
  syncedAt: String
}, { timestamps: true, collection: "orders" });

const saleSchema = new mongoose.Schema({
  taxes:[mongoose.Schema.Types.Mixed], charges:[mongoose.Schema.Types.Mixed], taxTotal:Number, taxableAmount:Number, taxSettings:mongoose.Schema.Types.Mixed, gstin:String, receiptFields:mongoose.Schema.Types.Mixed,
  orderType: String, tableId: String, tableName: String, dineSessionId: String,
  kitchenTickets: [mongoose.Schema.Types.Mixed],
  canteenId: { type: String, index: true, default: DEFAULT_CANTEEN_ID },
  orderId: Number,
  clientOrderId: { type: String, sparse: true, index: true },
  time: String,
  canteen: String,
  cashier: String,
  cashierMobile: String,
  branchAddress: String,
  payment: String,
  paymentBreakup: mongoose.Schema.Types.Mixed,
  creditName: String,
  subtotal: Number,
  discount: Number,
  total: Number,
  items: [{ id: Number, lineId: String, parentId: Number, name: String, nameTe: String, printName: String, optionName: String, price: Number, qty: Number, billingType: String, grams: Number, ratePerKg: Number, lineTotal: Number }],
  syncedAt: String
}, { timestamps: true, collection: "sales" });

const userSchema = new mongoose.Schema({
  canteenId: { type: String, index: true, default: DEFAULT_CANTEEN_ID },
  id: Number,
  name: String,
  mobile: { type: String, index: true },
  password: String,
  role: { type: String, enum: CANTEEN_ROLES, default: "user" },
  branchAddress: String,
  active: { type: Boolean, default: true },
  mustChangePassword: { type: Boolean, default: false }
}, { timestamps: true, collection: "users" });

const branchAddressSchema = new mongoose.Schema({
  canteenId: { type: String, index: true, default: DEFAULT_CANTEEN_ID },
  id: { type: Number, sparse: true, index: true },
  name: String,
  address: String,
  active: { type: Boolean, default: true }
}, { timestamps: true, collection: "branch_addresses" });

const menuItemSchema = new mongoose.Schema({
  canteenId: { type: String, index: true, default: DEFAULT_CANTEEN_ID },
  id: { type: Number, sparse: true, index: true },
  name: String,
  price: Number,
  halfPrice: Number,
  category: String,
  unit: String,
  billingType: { type: String, enum: ["quantity", "weight"], default: "quantity" },
  image: String,
  imageCredit: { source: String, license: String, author: String, licenseUrl: String },
  nameTe: String,
  subItems: [{ name: String, nameTe: String, price: Number }],
  sortOrder: Number,
  hidden: { type: Boolean, default: false }
}, { timestamps: true, collection: "menu_items" });

const globalCatalogItemSchema = new mongoose.Schema({
  catalogId: { type: Number, unique: true, index: true },
  name: { type: String, index: true },
  image: String,
  sourceCount: { type: Number, default: 1 },
  lastSeenCanteenId: String
}, { timestamps: true, collection: "global_catalog_items" });

const creditorSchema = new mongoose.Schema({
  canteenId: { type: String, index: true, default: DEFAULT_CANTEEN_ID },
  id: { type: Number, sparse: true, index: true },
  name: String,
  phone: String,
  address: String,
  reason: String,
  active: { type: Boolean, default: true }
}, { timestamps: true, collection: "creditors" });

const stockItemSchema = new mongoose.Schema({
  canteenId: { type: String, index: true, default: DEFAULT_CANTEEN_ID },
  id: { type: Number, sparse: true, index: true },
  item: String,
  stock: Number,
  unit: String,
  minStock: Number
}, { timestamps: true, collection: "stock_items" });

const stockUsageSchema = new mongoose.Schema({
  canteenId: { type: String, index: true, default: DEFAULT_CANTEEN_ID },
  id: { type: Number, sparse: true, index: true },
  itemId: Number,
  item: String,
  qtyUsed: Number,
  unit: String,
  date: String,
  storeKeeper: String,
  note: String
}, { timestamps: true, collection: "stock_usage" });

const expenseSchema = new mongoose.Schema({
  canteenId: { type: String, index: true, default: DEFAULT_CANTEEN_ID },
  id: { type: Number, sparse: true, index: true },
  title: String,
  amount: Number,
  category: String,
  time: String
}, { timestamps: true, collection: "expenses" });

const reportSettingSchema = new mongoose.Schema({
  taxSettings:mongoose.Schema.Types.Mixed,
  canteenId: { type: String, index: true, default: DEFAULT_CANTEEN_ID },
  key: { type: String, index: true, default: "app" },
  canteenName: String,
  brandName: String,
  tagline: String,
  logoUrl: String,
  receiptLogoPosition: String,
  receiptLogoSize: Number,
  receiptArea: String,
  menuLanguage: String,
  receiptLanguage: String,
  businessCategory: String,
  posMode: String,
  reportTime: String,
  adminWhatsAppNumber: String,
  reportPhone: String,
  autoReport: Boolean,
  reportType: String
}, { timestamps: true, collection: "report_settings" });

const canteenSchema = new mongoose.Schema({
  canteenId: { type: String, unique: true, index: true },
  name: String,
  businessCategory: String,
  ownerName: String,
  phone: String,
  address: String,
  plan: String,
  paymentStatus: String,
  paymentReference: String,
  active: { type: Boolean, default: true },
  createdByMarketingUser: String
}, { timestamps: true, collection: "canteens" });

const printerSchema = new mongoose.Schema({
  canteenId: { type: String, index: true },
  provider: String,
  model: String,
  serialNumber: String,
  bluetoothName: String,
  macAddress: String,
  status: { type: String, default: "Stock", index: true },
  allottedTo: String,
  allottedToName: String,
  marketingCanteenId: Number,
  marketingCanteenName: String,
  installedBy: String,
  installedAt: String
}, { timestamps: true, collection: "printers" });

const marketingUserSchema = new mongoose.Schema({
  employeeId: { type: String, unique: true, index: true },
  name: String,
  mobile: String,
  aadhaarNumber: String,
  panNumber: String,
  bankAccountName: String,
  bankAccountNumber: String,
  bankIfsc: String,
  bankUpi: String,
  password: String,
  role: { type: String, enum: ["marketing", "manager", "super_admin"], default: "marketing" },
  department: { type: String, default: "Marketing" },
  active: { type: Boolean, default: true },
  target: Number
}, { timestamps: true, collection: "marketing_users" });

const marketingCanteenSchema = new mongoose.Schema({
  dineInRequested: { type: Boolean, default: false },
  id: { type: Number, index: true },
  canteenName: String,
  businessCategory: String,
  ownerName: String,
  ownerMobile: String,
  alternateMobile: String,
  address: String,
  city: String,
  state: String,
  counters: Number,
  printersRequired: Number,
  printerModel: String,
  printerSerialNumber: String,
  selectedPlan: String,
  planType: String,
  planStartDate: String,
  planExpiryDate: String,
  demoDays: Number,
  requestedDemoDays: Number,
  paymentMode: String,
  paidAmount: Number,
  pendingAmount: Number,
  requestedPaidAmount: Number,
  requestedPendingAmount: Number,
  requestedPaymentMode: String,
  paymentApprovalStatus: String,
  paymentApprovalRequestedBy: String,
  paymentApprovalRequestedAt: String,
  commissionAmount: Number,
  menuSetupItems: [mongoose.Schema.Types.Mixed],
  notes: String,
  documents: String,
  status: { type: String, index: true },
  rejectionReason: String,
  activatedCanteenId: String,
  canteenLoginId: String,
  defaultPassword: String,
  online: Boolean,
  lastSeenAt: String,
  blocked: Boolean,
  printersAssigned: Number,
  currentStage: String,
  nextFollowUp: String,
  lastActivity: mongoose.Schema.Types.Mixed,
  activityTimeline: [mongoose.Schema.Types.Mixed],
  followUps: [mongoose.Schema.Types.Mixed],
  latitude: Number,
  longitude: Number,
  submittedBy: { type: String, index: true },
  submittedByName: String,
  approvedBy: String,
  approvedAt: String
  ,appReleaseId: String
  ,appReleaseVersion: String
  ,appInstalledVersion: String
  ,appInstalledAt: String
  ,posTrialReason: String
  ,takeawayEnabled: { type: Boolean, default: true }
}, { timestamps: true, collection: "marketing_canteens" });

const marketingActivitySchema = new mongoose.Schema({
  id: Number,
  type: String,
  text: String,
  actor: String,
  canteenId: Number,
  createdAt: String
}, { timestamps: true, collection: "marketing_activities" });

const marketingPaymentSchema = new mongoose.Schema({
  id: Number,
  canteenId: { type: Number, index: true },
  canteenName: String,
  amount: Number,
  pendingAmount: Number,
  paymentMode: String,
  paymentReference: String,
  notes: String,
  collectedBy: String,
  collectedByName: String
}, { timestamps: true, collection: "marketing_payments" });

const subscriptionOrderSchema = new mongoose.Schema({
  orderId: { type: String, unique: true, index: true },
  canteenId: { type: String, index: true },
  marketingCanteenId: Number,
  canteenName: String,
  planName: String,
  months: Number,
  amount: Number,
  currency: { type: String, default: "INR" },
  status: { type: String, index: true, default: "created" },
  paymentSessionId: String,
  cfOrderId: String,
  cfPaymentId: String,
  paymentStatus: String,
  paymentMode: String,
  oldExpiryDate: String,
  newExpiryDate: String,
  rawPayment: mongoose.Schema.Types.Mixed,
  createdByMobile: String
}, { timestamps: true, collection: "subscription_orders" });

const marketingSupportTicketSchema = new mongoose.Schema({
  id: Number,
  canteenId: { type: String, index: true },
  title: String,
  status: { type: String, index: true },
  canteenName: String,
  customerName: String,
  phone: String,
  problemType: String,
  message: String,
  submittedByLogin: String,
  priority: String,
  assignedTo: String,
  tags: [String],
  comments: [{ author: String, text: String, createdAt: String }],
  resolvedAt: Date,
  resolvedBy: String
}, { timestamps: true, collection: "marketing_support_tickets" });

const appReleaseSchema = new mongoose.Schema({
  version: { type: String, unique: true, index: true },
  notes: String,
  sha256: { type: String, index: true },
  signature: String,
  size: Number,
  status: { type: String, enum: ["Draft", "Published"], default: "Draft", index: true },
  bundle: Buffer,
  createdBy: String,
  publishedAt: Date
}, { timestamps: true, collection: "app_releases" });

const enquirySchema = new mongoose.Schema({
  id: { type: Number, index: true },
  name: String,
  phone: { type: String, index: true },
  email: String,
  plan: String,
  message: String,
  source: { type: String, default: "pos.axzen.in", index: true },
  status: { type: String, default: "New", index: true },
  assignedTo: String,
  notes: String
}, { timestamps: true, collection: "enquiries" });

const websitePlanSchema = new mongoose.Schema({
  id: { type: Number, unique: true, index: true },
  name: String,
  description: String,
  originalPrice: String,
  offerPrice: String,
  billingCycle: String,
  badge: String,
  cta: String,
  features: [String],
  popular: Boolean,
  active: { type: Boolean, default: true },
  sortOrder: Number
}, { timestamps: true, collection: "website_plans" });

const whatsappLogSchema = new mongoose.Schema({
  canteenId: { type: String, index: true, default: DEFAULT_CANTEEN_ID },
  time: String,
  success: Boolean,
  reason: String,
  to: String,
  message: String,
  error: String,
  meta: mongoose.Schema.Types.Mixed
}, { timestamps: true, collection: "whatsapp_logs" });

userSchema.index({ canteenId: 1, mobile: 1 }, { unique: true, name: "canteenId_1_mobile_1" });
branchAddressSchema.index({ canteenId: 1, id: 1 }, { unique: true, name: "canteenId_1_id_1" });
orderSchema.index(
  { canteenId: 1, clientOrderId: 1 },
  { unique: true, name: "canteenId_1_clientOrderId_1", partialFilterExpression: { clientOrderId: { $type: "string" } } }
);
saleSchema.index(
  { canteenId: 1, clientOrderId: 1 },
  { unique: true, name: "canteenId_1_clientOrderId_1", partialFilterExpression: { clientOrderId: { $type: "string" } } }
);
reportSettingSchema.index({ canteenId: 1, key: 1 }, { unique: true, name: "canteenId_1_key_1" });
menuItemSchema.index({ canteenId: 1, id: 1 }, { unique: true, name: "canteenId_1_id_1" });
globalCatalogItemSchema.index({ name: 1 }, { name: "name_1" });
creditorSchema.index({ canteenId: 1, id: 1 }, { unique: true, name: "canteenId_1_id_1" });
stockItemSchema.index({ canteenId: 1, id: 1 }, { unique: true, name: "canteenId_1_id_1" });
stockUsageSchema.index({ canteenId: 1, id: 1 }, { unique: true, name: "canteenId_1_id_1" });
expenseSchema.index({ canteenId: 1, id: 1 }, { unique: true, name: "canteenId_1_id_1" });

const Order = mongoose.models.Order || mongoose.model("Order", orderSchema);
const Sale = mongoose.models.Sale || mongoose.model("Sale", saleSchema);
const User = mongoose.models.User || mongoose.model("User", userSchema);
const BranchAddress = mongoose.models.BranchAddress || mongoose.model("BranchAddress", branchAddressSchema);
const MenuItem = mongoose.models.MenuItem || mongoose.model("MenuItem", menuItemSchema);
const GlobalCatalogItem = mongoose.models.GlobalCatalogItem || mongoose.model("GlobalCatalogItem", globalCatalogItemSchema);
const Creditor = mongoose.models.Creditor || mongoose.model("Creditor", creditorSchema);
const StockItem = mongoose.models.StockItem || mongoose.model("StockItem", stockItemSchema);
const StockUsage = mongoose.models.StockUsage || mongoose.model("StockUsage", stockUsageSchema);
const Expense = mongoose.models.Expense || mongoose.model("Expense", expenseSchema);
const ReportSetting = mongoose.models.ReportSetting || mongoose.model("ReportSetting", reportSettingSchema);
const Canteen = mongoose.models.Canteen || mongoose.model("Canteen", canteenSchema);
const Printer = mongoose.models.Printer || mongoose.model("Printer", printerSchema);
const MarketingUser = mongoose.models.MarketingUser || mongoose.model("MarketingUser", marketingUserSchema);
const MarketingCanteen = mongoose.models.MarketingCanteen || mongoose.model("MarketingCanteen", marketingCanteenSchema);
const MarketingActivity = mongoose.models.MarketingActivity || mongoose.model("MarketingActivity", marketingActivitySchema);
const MarketingPayment = mongoose.models.MarketingPayment || mongoose.model("MarketingPayment", marketingPaymentSchema);
const SubscriptionOrder = mongoose.models.SubscriptionOrder || mongoose.model("SubscriptionOrder", subscriptionOrderSchema);
const MarketingSupportTicket = mongoose.models.MarketingSupportTicket || mongoose.model("MarketingSupportTicket", marketingSupportTicketSchema);
const AppRelease = mongoose.models.AppRelease || mongoose.model("AppRelease", appReleaseSchema);
const Enquiry = mongoose.models.Enquiry || mongoose.model("Enquiry", enquirySchema);
const WebsitePlan = mongoose.models.WebsitePlan || mongoose.model("WebsitePlan", websitePlanSchema);
const WhatsappLog = mongoose.models.WhatsappLog || mongoose.model("WhatsappLog", whatsappLogSchema);

function nextId(items) {
  return items.reduce((max, item) => Math.max(max, Number(item.id || item.orderId || 0)), 0) + 1;
}

function normalizeMobile(value) {
  return String(value || "").trim();
}

function normalizeCanteenId(value) {
  return String(value || "").trim().toUpperCase();
}

function canteenScopedUserQuery(canteenId, mobile) {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  const mobileValue = normalizeMobile(mobile);
  const canteenClause = targetCanteenId === DEFAULT_CANTEEN_ID
    ? { $or: [{ canteenId: targetCanteenId }, { canteenId: { $exists: false } }, { canteenId: null }, { canteenId: "" }] }
    : { canteenId: targetCanteenId };
  return { ...canteenClause, mobile: mobileValue, active: { $ne: false } };
}

function publicUser(user) {
  if (!user) return null;
  return {
    id: String(user._id || user.id || user.mobile),
    name: user.name,
    mobile: user.mobile,
    role: user.role,
    branchAddress: user.branchAddress || "",
    active: user.active !== false,
    canteenId: user.canteenId || DEFAULT_CANTEEN_ID,
    mustChangePassword: user.mustChangePassword === true
  };
}

function signToken(user) {
  const payload = { ...publicUser(user), authType: "canteen" };
  if (!process.env.JWT_SECRET) {
    return `local.${encodeLocalToken({ ...payload, exp: Date.now() + 7 * 24 * 60 * 60 * 1000 })}`;
  }
  return jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: "7d" });
}

function encodeLocalToken(payload) {
  return Buffer.from(JSON.stringify(payload)).toString("base64url");
}

function decodeLocalToken(token) {
  return JSON.parse(Buffer.from(token, "base64url").toString("utf8"));
}

function publicMarketingUser(user) {
  if (!user) return null;
  return {
    id: String(user._id || user.employeeId),
    employeeId: user.employeeId,
    name: user.name,
    mobile: user.mobile || "",
    aadhaarNumber: user.aadhaarNumber || "",
    panNumber: user.panNumber || "",
    bankAccountName: user.bankAccountName || "",
    bankAccountNumber: user.bankAccountNumber || "",
    bankIfsc: user.bankIfsc || "",
    bankUpi: user.bankUpi || "",
    role: user.role,
    department: user.department || "Marketing",
    active: user.active !== false,
    target: Number(user.target || 0)
  };
}

function signMarketingToken(user) {
  const payload = { ...publicMarketingUser(user), authType: "marketing" };
  if (!process.env.JWT_SECRET) {
    return `local.${encodeLocalToken({ ...payload, exp: Date.now() + 7 * 24 * 60 * 60 * 1000 })}`;
  }
  return jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: "7d" });
}

function requireMarketingAuth(req, res, next) {
  const token = String(req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!token) return res.status(401).json({ success: false, message: "Login token missing" });
  try {
    const user = process.env.JWT_SECRET
      ? jwt.verify(token, process.env.JWT_SECRET)
      : decodeLocalToken(token.replace(/^local\./, ""));
    if (user.authType !== "marketing") return res.status(401).json({ success: false, message: "Invalid marketing token" });
    if (!process.env.JWT_SECRET && Number(user.exp || 0) < Date.now()) {
      return res.status(401).json({ success: false, message: "Invalid or expired login token" });
    }
    req.marketingUser = user;
    if (String(user.department || "") === "Help Center") {
      const path = String(req.path || "");
      const allowed = path === "/marketing-api/me" || path === "/marketing-api/dashboard" || path.startsWith("/marketing-api/help-tickets");
      if (!allowed) return res.status(403).json({ success: false, message: "Help Center access only" });
    }
    return next();
  } catch {
    return res.status(401).json({ success: false, message: "Invalid or expired login token" });
  }
}

function requireHelpDesk(req, res, next) {
  return requireMarketingAuth(req, res, () => {
    const role = req.marketingUser.role;
    if (role === "super_admin" || role === "manager" || req.marketingUser.department === "Help Center") return next();
    return res.status(403).json({ success: false, message: "Help Center access required" });
  });
}

function requireSuperAdmin(req, res, next) {
  return requireMarketingAuth(req, res, () => {
    if (req.marketingUser.role !== "super_admin" && req.marketingUser.role !== "manager") {
      return res.status(403).json({ success: false, message: "Manager or super admin access required" });
    }
    return next();
  });
}

function canteenUserFromRequest(req) {
  const token = String(req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!token) return null;
  try {
    const user = process.env.JWT_SECRET
      ? jwt.verify(token, process.env.JWT_SECRET)
      : decodeLocalToken(token.replace(/^local\./, ""));
    if (user.authType !== "canteen") return null;
    if (!process.env.JWT_SECRET && Number(user.exp || 0) < Date.now()) return null;
    return user;
  } catch {
    return null;
  }
}

async function canteenCanLogin(canteenId) {
  return (await canteenAccessStatus(canteenId)).allowed;
}

function isPastDate(dateValue) {
  if (!dateValue) return false;
  const end = new Date(`${String(dateValue).slice(0, 10)}T23:59:59.999+05:30`);
  return Number.isFinite(end.getTime()) && end.getTime() < Date.now();
}

function addDaysDate(days, startDate = new Date()) {
  const date = new Date(startDate);
  date.setDate(date.getDate() + Math.max(0, Number(days || 0)));
  return date.toISOString().slice(0, 10);
}

function addMonthsDate(months, startDate = new Date()) {
  const date = new Date(startDate);
  date.setMonth(date.getMonth() + Math.max(0, Number(months || 0)));
  return date.toISOString().slice(0, 10);
}

function planExpiryFromPayload(payload, current = {}) {
  if (payload.planExpiryDate) return String(payload.planExpiryDate);
  const trialDays = Number(payload.trialDays || payload.trailDays || 0);
  if (trialDays > 0) return addDaysDate(trialDays, payload.planStartDate || current.planStartDate || new Date());
  const months = Number(payload.months || payload.planMonths || 0);
  if (months > 0) return addMonthsDate(months, payload.planStartDate || current.planStartDate || new Date());
  return String(current.planExpiryDate || "");
}

async function canteenAccessStatus(canteenId) {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  if (!targetCanteenId) return { allowed: false, message: "Invalid canteen" };
  if (!mongoReady) return { allowed: false, message: "Database not connected" };

  const marketing = await MarketingCanteen.findOne({ activatedCanteenId: targetCanteenId }).lean();
  if (marketing?.status === "Expired" || isPastDate(marketing?.planExpiryDate)) {
    if (marketing && marketing.status !== "Expired") {
      await MarketingCanteen.updateOne({ _id: marketing._id }, { $set: { status: "Expired", online: false, updatedAt: new Date().toISOString() } }).catch(() => {});
      await Canteen.updateOne({ canteenId: targetCanteenId }, { $set: { active: false } }).catch(() => {});
    }
    return { allowed: true, expired: true, message: TRIAL_EXPIRED_MESSAGE };
  }

  const core = await Canteen.findOne({ canteenId: targetCanteenId }).lean();
  if (core && core.active === false) return { allowed: false, message: "Canteen access is inactive or blocked" };

  if (!marketing) return { allowed: Boolean(core) || targetCanteenId === DEFAULT_CANTEEN_ID, message: "Canteen access is inactive or blocked" };
  if (marketing.blocked || marketing.status === "Blocked" || marketing.status === "Rejected" || marketing.status === "Expired") {
    return { allowed: false, message: marketing.status === "Expired" ? TRIAL_EXPIRED_MESSAGE : "Canteen access is inactive or blocked" };
  }
  return { allowed: ["Active", "Trial"].includes(marketing.status) || Boolean(marketing.canteenLoginId), message: "Canteen access is inactive or blocked" };
}

async function tokenUserIsCurrent(user) {
  if (!user || !mongoReady) return false;
  const canteenId = normalizeCanteenId(user.canteenId || DEFAULT_CANTEEN_ID);
  const current = await User.findOne(canteenScopedUserQuery(canteenId, user.mobile)).lean();
  if (!current) return false;
  if (current.role !== user.role) return false;
  return canteenCanLogin(canteenId);
}

async function tokenUserAccessStatus(user) {
  if (!user || !mongoReady) return { allowed: false, message: "Invalid or expired login token" };
  const canteenId = normalizeCanteenId(user.canteenId || DEFAULT_CANTEEN_ID);
  const current = await User.findOne(canteenScopedUserQuery(canteenId, user.mobile)).lean();
  if (!current || current.role !== user.role) return { allowed: false, message: "Canteen access is inactive or blocked" };
  return canteenAccessStatus(canteenId);
}

async function markCanteenSeen(canteenId, installedVersion = "") {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  const seen = new Date().toISOString();
  const version = String(installedVersion || "").trim().slice(0, 40);
  const patch = { online: true, lastSeenAt: seen };
  if (version) {
    patch.appInstalledVersion = version;
    patch.appInstalledAt = seen;
  }
  if (!mongoReady) {
    const item = memory.marketingCanteens.find(row => normalizeCanteenId(row.activatedCanteenId) === targetCanteenId);
    if (item) Object.assign(item, patch);
    return;
  }
  await MarketingCanteen.findOneAndUpdate({ activatedCanteenId: targetCanteenId }, { $set: patch });
}

function decodeCanteenAuthToken(req) {
  const token = String(req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!token) return { error: "Login token missing" };
  try {
    const user = process.env.JWT_SECRET
      ? jwt.verify(token, process.env.JWT_SECRET)
      : decodeLocalToken(token.replace(/^local\./, ""));
    if (user.authType !== "canteen") return { error: "Invalid canteen token" };
    if (!process.env.JWT_SECRET && Number(user.exp || 0) < Date.now()) {
      return { error: "Invalid or expired login token" };
    }
    return { user };
  } catch {
    return { error: "Invalid or expired login token" };
  }
}

async function requireAdmin(req, res, next) {
  const decoded = decodeCanteenAuthToken(req);
  if (decoded.error) return res.status(401).json({ success: false, message: decoded.error });
  try {
    req.authUser = decoded.user;
    if (req.authUser.role !== "admin") {
      return res.status(403).json({ success: false, message: "Admin access required" });
    }
    const access = await tokenUserAccessStatus(req.authUser);
    if (!access.allowed) {
      return res.status(403).json({ success: false, message: access.message });
    }
    markCanteenSeen(req.authUser.canteenId, req.get("x-axzen-app-version")).catch(() => {});
    return next();
  } catch (error) {
    return res.status(401).json({ success: false, message: "Invalid or expired login token" });
  }
}

async function requireStockAccess(req, res, next) {
  const decoded = decodeCanteenAuthToken(req);
  if (decoded.error) return res.status(401).json({ success: false, message: decoded.error });
  try {
    req.authUser = decoded.user;
    if (!["admin", "store_keeper", "inventory", "manager"].includes(req.authUser.role)) {
      return res.status(403).json({ success: false, message: "Stock access required" });
    }
    const access = await tokenUserAccessStatus(req.authUser);
    if (!access.allowed) {
      return res.status(403).json({ success: false, message: access.message });
    }
    markCanteenSeen(req.authUser.canteenId, req.get("x-axzen-app-version")).catch(() => {});
    return next();
  } catch (error) {
    return res.status(401).json({ success: false, message: "Invalid or expired login token" });
  }
}

async function requireCanteenAuth(req, res, next) {
  const decoded = decodeCanteenAuthToken(req);
  if (decoded.error) return res.status(401).json({ success: false, message: decoded.error });
  try {
    req.authUser = decoded.user;
    if (!CANTEEN_ROLES.includes(req.authUser.role)) {
      return res.status(403).json({ success: false, message: "Canteen user access required" });
    }
    const access = await tokenUserAccessStatus(req.authUser);
    if (!access.allowed) {
      return res.status(403).json({ success: false, message: access.message });
    }
    markCanteenSeen(req.authUser.canteenId, req.get("x-axzen-app-version")).catch(() => {});
    return next();
  } catch (error) {
    return res.status(401).json({ success: false, message: "Invalid or expired login token" });
  }
}

function requireCanteenTokenOnly(req, res, next) {
  const decoded = decodeCanteenAuthToken(req);
  if (decoded.error) return res.status(401).json({ success: false, message: decoded.error });
  if (!decoded.user || !CANTEEN_ROLES.includes(decoded.user.role)) {
    return res.status(403).json({ success: false, message: "Canteen user access required" });
  }
  req.authUser = decoded.user;
  return next();
}

function requireDatabase(req, res, next) {
  if (!mongoReady) {
    return res.status(503).json({
      success: false,
      message: "Database not connected. Data was not saved. Please check MongoDB connection."
    });
  }
  return next();
}

async function seedDefaults() {
  for (const user of defaultUsers) {
    await User.findOneAndUpdate(
      { canteenId: user.canteenId || DEFAULT_CANTEEN_ID, mobile: user.mobile },
      { $setOnInsert: { ...user, canteenId: user.canteenId || DEFAULT_CANTEEN_ID } },
      { upsert: true }
    );
  }
  if (!await MenuItem.countDocuments()) await MenuItem.insertMany(defaultMenuItems);
  if (!await StockItem.countDocuments()) await StockItem.insertMany(defaultStockItems);
  await ReportSetting.findOneAndUpdate(
    { key: "app", canteenId: DEFAULT_CANTEEN_ID },
    { $setOnInsert: { ...defaultSettings, canteenId: DEFAULT_CANTEEN_ID } },
    { upsert: true }
  );
  for (const user of defaultMarketingUsers) {
    await MarketingUser.findOneAndUpdate(
      { employeeId: user.employeeId },
      { $setOnInsert: user },
      { upsert: true }
    );
  }
  if (!await MarketingCanteen.countDocuments()) await MarketingCanteen.insertMany(defaultMarketingCanteens);
  if (!await MarketingActivity.countDocuments()) await MarketingActivity.insertMany(memory.marketingActivities);
  if (!await MarketingPayment.countDocuments()) await MarketingPayment.insertMany(defaultMarketingPayments);
  if (!await MarketingSupportTicket.countDocuments()) await MarketingSupportTicket.insertMany(defaultMarketingSupportTickets);
  if (!await WebsitePlan.countDocuments()) await WebsitePlan.insertMany(defaultWebsitePlans);
  if (!await GlobalCatalogItem.countDocuments()) {
    await GlobalCatalogItem.insertMany(defaultCatalogItems.map(item => ({
      catalogId: item.id,
      name: item.name,
      image: item.image || "",
      sourceCount: 1,
      lastSeenCanteenId: DEFAULT_CANTEEN_ID
    })));
  }
  const catalogCount = await GlobalCatalogItem.countDocuments();
  const menuCount = await MenuItem.countDocuments();
  if (catalogCount < Math.min(menuCount, 100)) await syncGlobalCatalogFromMenuItems();
  await reconcileApprovedCanteens();
}

async function dropIndexIfExists(collection, name) {
  try {
    const indexes = await collection.indexes();
    if (indexes.some(index => index.name === name)) {
      await collection.dropIndex(name);
    }
  } catch (error) {
    if (error.codeName !== "IndexNotFound") throw error;
  }
}

async function ensureDatabaseIndexes() {
  await dropIndexIfExists(User.collection, "mobile_1");
  await User.collection.createIndex(
    { canteenId: 1, mobile: 1 },
    { unique: true, name: "canteenId_1_mobile_1" }
  );

  await dropIndexIfExists(Order.collection, "clientOrderId_1");
  await Order.collection.createIndex(
    { canteenId: 1, clientOrderId: 1 },
    {
      unique: true,
      name: "canteenId_1_clientOrderId_1",
      partialFilterExpression: { clientOrderId: { $type: "string" } }
    }
  );

  await dropIndexIfExists(Sale.collection, "clientOrderId_1");
  await Sale.collection.createIndex(
    { canteenId: 1, clientOrderId: 1 },
    {
      unique: true,
      name: "canteenId_1_clientOrderId_1",
      partialFilterExpression: { clientOrderId: { $type: "string" } }
    }
  );

  await dropIndexIfExists(ReportSetting.collection, "key_1");
  await ReportSetting.collection.createIndex(
    { canteenId: 1, key: 1 },
    { unique: true, name: "canteenId_1_key_1" }
  );

  for (const collection of [MenuItem.collection, Creditor.collection, BranchAddress.collection, StockItem.collection, StockUsage.collection, Expense.collection]) {
    await dropIndexIfExists(collection, "id_1");
    await collection.createIndex(
      { canteenId: 1, id: 1 },
      { unique: true, name: "canteenId_1_id_1" }
    );
  }
  await GlobalCatalogItem.collection.createIndex({ name: 1 }, { name: "name_1" });
}

async function connectDatabase() {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    mongoReady = false;
    mongoError = "MONGODB_URI missing";
    console.log("MONGODB_URI missing. Running with local memory fallback.");
    return false;
  }

  if (mongoose.connection.readyState === 1) {
    mongoReady = true;
    mongoError = "";
    return true;
  }

  try {
    await mongoose.connect(uri, { dbName: DB_NAME, serverSelectionTimeoutMS: 8000 });
    mongoReady = true;
    mongoError = "";
    await ensureDatabaseIndexes();
    await seedDefaults();
    console.log(`MongoDB Atlas connected: ${DB_NAME}`);
    return true;
  } catch (error) {
    mongoReady = false;
    mongoError = error.message;
    console.log("MongoDB Atlas connection failed:", error.message);
    return false;
  }
}

function modelToPlain(doc) {
  return doc && typeof doc.toObject === "function" ? doc.toObject() : doc;
}

async function allMenuItems(canteenId = DEFAULT_CANTEEN_ID, options = {}) {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  const byOrder = (a, b) => Number(a.sortOrder ?? a.id ?? 0) - Number(b.sortOrder ?? b.id ?? 0);
  const includeHidden = options.includeHidden === true;
  const config = await getSettings(targetCanteenId);
  const restaurant = shopKindFromCategory(config.businessCategory, config.posMode) === "canteen";
  const normalizeBilling = row => restaurant && row.billingType === "weight" && !["kg", "kgs", "kilogram", "kilograms", "g", "gram", "grams"].includes(String(row.unit || row.saleUnit || row.weightUnit || "").trim().toLowerCase())
    ? { ...row, billingType: "quantity", unit: row.unit || "Plate" } : row;
  if (!mongoReady) {
    return memory.menuItems
      .filter(item => normalizeCanteenId(item.canteenId || DEFAULT_CANTEEN_ID) === targetCanteenId)
      .filter(item => includeHidden || item.hidden !== true)
      .sort(byOrder).map(normalizeBilling);
  }
  const query = includeHidden ? { canteenId: targetCanteenId } : { canteenId: targetCanteenId, hidden: { $ne: true } };
  return (await MenuItem.find(query).lean()).sort(byOrder).map(normalizeBilling);
}

async function globalItemSuggestions(search = "", canteenId = DEFAULT_CANTEEN_ID) {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  const query = String(search || "").trim().toLowerCase();
  if (query.length < 2) return [];
  const currentNames = new Set((await allMenuItems(targetCanteenId, { includeHidden: true })).map(item => String(item.name || "").trim().toLowerCase()));
  const rows = [];
  const push = item => {
    const name = String(item?.name || "").trim();
    if (!name || !name.toLowerCase().includes(query)) return;
    rows.push({
      catalogId: Number(item.catalogId || item.id || 0),
      name,
      nameTe: String(item.nameTe || item.teluguName || "").trim(),
      image: String(item.image || "").trim(),
      category: String(item.category || "Snacks").trim() || "Snacks",
      active: currentNames.has(name.toLowerCase())
    });
  };
  defaultCatalogItems.forEach(push);
  if (!mongoReady) {
    memory.globalCatalogItems.forEach(push);
    memory.menuItems.forEach(push);
  } else {
    const regex = new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
    (await GlobalCatalogItem.find({ name: regex }).select("catalogId name image").limit(80).lean()).forEach(push);
    (await MenuItem.find({ name: regex }).select("name nameTe image category").limit(80).lean()).forEach(push);
  }
  const unique = new Map();
  rows.forEach(item => {
    const key = item.name.toLowerCase();
    const current = unique.get(key);
    if (!current || (!current.image && item.image) || (current.active && !item.active)) unique.set(key, item);
  });
  return [...unique.values()]
    .sort((a, b) => Number(b.image ? 1 : 0) - Number(a.image ? 1 : 0) || Number(a.active) - Number(b.active) || a.name.localeCompare(b.name))
    .slice(0, 12);
}

async function upsertGlobalCatalogItem(item, options = {}) {
  const name = String(item?.name || "").replace(/\s+/g, " ").trim();
  if (!name) return null;
  const image = String(item.image || "").trim();
  if (!mongoReady) {
    const existing = memory.globalCatalogItems.find(row => String(row.name || "").toLowerCase() === name.toLowerCase());
    if (existing) {
      if (image && !existing.image) existing.image = image;
      existing.sourceCount = Number(existing.sourceCount || 1) + 1;
      existing.lastSeenCanteenId = item.canteenId || existing.lastSeenCanteenId || DEFAULT_CANTEEN_ID;
      return existing;
    }
    const entry = { catalogId: nextId(memory.globalCatalogItems), name, image, sourceCount: 1, lastSeenCanteenId: item.canteenId || DEFAULT_CANTEEN_ID };
    memory.globalCatalogItems.push(entry);
    return entry;
  }
  const existing = await GlobalCatalogItem.findOne({ name: new RegExp(`^${name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`, "i") }).lean();
  const next = {
    catalogId: existing?.catalogId || (Date.now() + Math.floor(Math.random() * 1000)),
    name,
    lastSeenCanteenId: item.canteenId || DEFAULT_CANTEEN_ID,
    updatedAt: new Date()
  };
  if (image) next.image = image;
  const update = existing
    ? (options.increment === false ? { $set: next } : { $set: next, $inc: { sourceCount: 1 } })
    : { $set: { ...next, sourceCount: 1 } };
  return GlobalCatalogItem.findOneAndUpdate(existing ? { _id: existing._id } : { name }, update, { upsert: true, new: true }).lean();
}

async function syncGlobalCatalogFromMenuItems() {
  if (!mongoReady) return;
  const seen = await MenuItem.find({ name: { $type: "string", $ne: "" } })
    .select("canteenId name image")
    .sort({ updatedAt: -1 })
    .limit(3000)
    .lean();
  for (const item of seen) {
    await upsertGlobalCatalogItem(item, { increment: false }).catch(() => {});
  }
}

function normalizeSubItems(value) {
  if (Array.isArray(value)) {
    return value
      .map(item => ({
        name: String(item && item.name || "").trim(),
        nameTe: String(item && (item.nameTe || item.teluguName) || "").trim(),
        price: Number(item && item.price || 0)
      }))
      .filter(item => item.name && item.price >= 0);
  }

  return String(value || "")
    .split(/\r?\n/)
    .map(line => {
      const [name, price] = line.split(":");
      return { name: String(name || "").trim(), price: Number(price || 0) };
    })
    .filter(item => item.name && item.price >= 0);
}

async function saveMenuItem(payload) {
  const canteenId = normalizeCanteenId(payload.canteenId || DEFAULT_CANTEEN_ID);
  const current = await allMenuItems(canteenId, { includeHidden: true });
  const item = {
    id: payload.id ? Number(payload.id) : nextId(current),
    canteenId,
    name: String(payload.name || "").trim(),
    nameTe: String(payload.nameTe || payload.teluguName || "").trim(),
    price: Number(payload.price || 0),
    halfPrice: Number(payload.halfPrice || payload.singlePrice || payload.halfItemPrice || 0),
    category: payload.category || "Snacks",
    unit: String(payload.unit || payload.saleUnit || "Plate").trim() || "Plate",
    billingType: payload.billingType === "weight" ? "weight" : "quantity",
    image: payload.image || "",
    imageCredit: payload.imageCredit && typeof payload.imageCredit === "object" ? { source: String(payload.imageCredit.source || "").slice(0,1000), license: String(payload.imageCredit.license || "").slice(0,100), author: String(payload.imageCredit.author || "").slice(0,500), licenseUrl: String(payload.imageCredit.licenseUrl || "").slice(0,1000) } : undefined,
    subItems: normalizeSubItems(payload.subItems),
    sortOrder: payload.sortOrder !== undefined && payload.sortOrder !== "" ? Number(payload.sortOrder) : Number(payload.id || nextId(current)),
    hidden: payload.hidden === true || payload.hidden === "true"
  };

  if (!item.name) throw new Error("Product name is required");

  const sameName = current.find(row =>
    String(row.name || "").trim().toLowerCase() === item.name.toLowerCase() &&
    Number(row.id) !== Number(item.id)
  );
  if (sameName) {
    const updatingExistingId = current.some(row => Number(row.id) === Number(item.id));
    if (updatingExistingId) throw new Error("This item is already in your menu");
    item.id = Number(sameName.id);
    if (!item.image) item.image = sameName.image || "";
    if (!item.nameTe) item.nameTe = sameName.nameTe || "";
    if (!item.unit && sameName.unit) item.unit = sameName.unit;
    if ((!item.subItems || !item.subItems.length) && Array.isArray(sameName.subItems)) item.subItems = sameName.subItems;
  }

  if (!mongoReady) {
    const existing = memory.menuItems.find(row =>
      normalizeCanteenId(row.canteenId || DEFAULT_CANTEEN_ID) === canteenId &&
      Number(row.id) === Number(item.id)
    );
    if (existing) Object.assign(existing, item);
    else memory.menuItems.push(item);
    await upsertGlobalCatalogItem(item);
    return item;
  }

  const saved = modelToPlain(await MenuItem.findOneAndUpdate(
    { canteenId, id: item.id },
    { $set: item },
    { new: true, upsert: true }
  ));
  await upsertGlobalCatalogItem(saved).catch(error => console.warn("Global catalog update failed:", error.message));
  return saved;
}

async function deleteMenuItem(id, canteenId = DEFAULT_CANTEEN_ID) {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  if (!mongoReady) {
    memory.menuItems = memory.menuItems.filter(item =>
      normalizeCanteenId(item.canteenId || DEFAULT_CANTEEN_ID) !== targetCanteenId ||
      Number(item.id) !== Number(id)
    );
    return;
  }
  await MenuItem.deleteOne({ canteenId: targetCanteenId, id: Number(id) });
}

async function allCreditors(canteenId = DEFAULT_CANTEEN_ID) {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  const byName = (a, b) => String(a.name || "").localeCompare(String(b.name || ""));
  if (!mongoReady) {
    return memory.creditors
      .filter(item => normalizeCanteenId(item.canteenId || DEFAULT_CANTEEN_ID) === targetCanteenId)
      .filter(item => item.active !== false)
      .sort(byName);
  }
  return (await Creditor.find({ canteenId: targetCanteenId, active: { $ne: false } }).lean()).sort(byName);
}

async function saveCreditor(payload) {
  const canteenId = normalizeCanteenId(payload.canteenId || DEFAULT_CANTEEN_ID);
  const current = await allCreditors(canteenId);
  const creditor = {
    id: payload.id ? Number(payload.id) : nextId(current),
    canteenId,
    name: String(payload.name || "").trim(),
    phone: String(payload.phone || "").trim(),
    address: String(payload.address || "").trim(),
    reason: String(payload.reason || "").trim(),
    active: payload.active !== false
  };

  if (!creditor.name) throw new Error("Creditor name is required");

  if (!mongoReady) {
    const existing = memory.creditors.find(row =>
      normalizeCanteenId(row.canteenId || DEFAULT_CANTEEN_ID) === canteenId &&
      Number(row.id) === Number(creditor.id)
    );
    if (existing) Object.assign(existing, creditor);
    else memory.creditors.push(creditor);
    return creditor;
  }

  return modelToPlain(await Creditor.findOneAndUpdate(
    { canteenId, id: creditor.id },
    { $set: creditor },
    { new: true, upsert: true }
  ));
}

const CANTEEN_MEAL_CATEGORIES = ["tiffin", "breakfast", "meals", "biryani", "starters", "chinese", "lunch", "dinner", "desserts", "tea", "coffee"];
const CANTEEN_MEAL_NAMES = ["idly", "idli", "dosa", "vada", "poori", "puri", "chapati", "parota", "paratha", "pongal", "upma", "meals", "biryani", "lemon rice", "curd rice", "bonda"];

function shopKindFromCategory(category = "", posMode = "") {
  const text = `${category} ${posMode}`.toLowerCase();
  if (["chicken", "meat", "meet", "mutton", "fish", "seafood"].some(keyword => text.includes(keyword))) return "chicken";
  if (["cool", "drink", "juice"].some(keyword => text.includes(keyword))) return "drinks";
  if (["retail", "super", "grocery"].some(keyword => text.includes(keyword))) return "retail";
  return "canteen";
}

function posModeForCategory(category = "", posMode = "") {
  return shopKindFromCategory(category, posMode) === "chicken" ? "chicken_shop" : "canteen";
}

function isCanteenMealItem(item) {
  const category = String(item?.category || "").toLowerCase();
  const name = String(item?.name || "").toLowerCase();
  if (CANTEEN_MEAL_CATEGORIES.some(keyword => category.includes(keyword))) return true;
  return CANTEEN_MEAL_NAMES.some(keyword => name.includes(keyword));
}

function isChickenLikeItem(item) {
  const category = String(item?.category || "").toLowerCase();
  const name = String(item?.name || "").toLowerCase();
  if (item?.billingType === "weight") return true;
  if (["chicken", "meat", "mutton", "fish", "seafood", "egg"].some(keyword => category.includes(keyword))) return true;
  if (name.includes("egg")) return true;
  return ["chicken", "meat", "mutton", "fish", "keema", "liver", "wings"].some(keyword => name.includes(keyword));
}

function itemFitsBusinessCategory(item, businessCategory = "Canteen", posMode = "") {
  const kind = shopKindFromCategory(businessCategory, posMode);
  if (kind === "chicken") {
    if (isChickenLikeItem(item)) return true;
    const category = String(item?.category || "").toLowerCase();
    return ["snacks", "drinks", "juice"].some(keyword => category.includes(keyword)) && !isCanteenMealItem(item);
  }
  if (kind === "drinks") {
    const category = String(item?.category || "").toLowerCase();
    const name = String(item?.name || "").toLowerCase();
    return ["juice", "drinks"].some(keyword => category.includes(keyword)) || /water|juice|soda|cool|drink/.test(name);
  }
  if (kind === "retail") {
    const category = String(item?.category || "").toLowerCase();
    return ["drinks", "snacks", "juice"].some(keyword => category.includes(keyword)) && !isCanteenMealItem(item);
  }
  return true;
}

function inferMenuCategory(name = "", businessCategory = "Canteen") {
  const value = String(name || "").toLowerCase();
  if (["chicken", "mutton", "meat", "fish", "keema"].some(keyword => value.includes(keyword))) return "Chicken";
  if (value.includes("egg")) return "Chicken";
  if (["idly", "idli", "dosa", "vada", "poori", "puri", "pongal", "upma"].some(keyword => value.includes(keyword))) return "Tiffin";
  if (value.includes("biryani")) return "Biryani";
  if (value.includes("meal")) return "Meals";
  if (value.includes("tea")) return "Tea";
  if (value.includes("coffee")) return "Coffee";
  if (value.includes("juice")) return "Juice";
  const kind = shopKindFromCategory(businessCategory);
  if (kind === "chicken") return "Chicken";
  if (kind === "drinks") return "Drinks";
  return "Snacks";
}

function defaultMenuForBusinessCategory(category = "Canteen") {
  const kind = shopKindFromCategory(category);
  if (kind === "chicken") return [];
  if (kind === "drinks") {
    return defaultMenuItems.filter(item => ["Juice", "Drinks"].includes(item.category) || ["Water Bottle"].includes(item.name));
  }
  if (kind === "retail") {
    return defaultMenuItems.filter(item => ["Drinks", "Snacks", "Juice"].includes(item.category));
  }
  return defaultMenuItems.filter(item => item.billingType !== "weight");
}

async function sanitizeMenuForBusinessCategory(canteenId, businessCategory, posMode) {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  if (shopKindFromCategory(businessCategory, posMode) === "canteen") return;
  const items = await allMenuItems(targetCanteenId, { includeHidden: true });
  const mismatched = items.filter(item => item.hidden !== true && !itemFitsBusinessCategory(item, businessCategory, posMode));
  if (!mismatched.length) return;
  if (!mongoReady) {
    mismatched.forEach(item => { item.hidden = true; });
    return;
  }
  await MenuItem.updateMany(
    { canteenId: targetCanteenId, id: { $in: mismatched.map(item => Number(item.id)) } },
    { $set: { hidden: true } }
  );
}

async function allCatalogItemsForCanteen(canteenId = DEFAULT_CANTEEN_ID, search = "") {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  const query = String(search || "").trim().toLowerCase();
  const currentItems = await allMenuItems(targetCanteenId, { includeHidden: true });
  const currentNames = new Set(currentItems.map(item => String(item.name || "").trim().toLowerCase()));
  const rows = [];
  const push = item => {
    const name = String(item?.name || "").replace(/\s+/g, " ").trim();
    if (!name) return;
    if (query && !name.toLowerCase().includes(query) && !String(item.category || "").toLowerCase().includes(query)) return;
    rows.push({
      catalogId: Number(item.catalogId || item.id || 0),
      name,
      nameTe: String(item.nameTe || item.teluguName || "").trim(),
      image: String(item.image || "").trim(),
      imageCredit: item.imageCredit,
      category: String(item.category || inferMenuCategory(name)).trim() || "Snacks",
      billingType: item.billingType === "weight" ? "weight" : "quantity",
      unit: String(item.unit || "").trim(),
      active: currentNames.has(name.toLowerCase())
    });
  };
  currentItems.forEach(push);
  defaultCatalogItems.forEach(push);
  if (!mongoReady) {
    memory.globalCatalogItems.forEach(push);
  } else {
    (await GlobalCatalogItem.find({}).select("catalogId name image").sort({ sourceCount: -1, name: 1 }).limit(800).lean()).forEach(push);
  }
  const unique = new Map();
  rows.forEach(item => {
    const key = item.name.toLowerCase();
    const current = unique.get(key);
    if (!current || (!current.image && item.image) || (current.active && !item.active)) unique.set(key, { ...item, active: currentNames.has(key) });
  });
  return [...unique.values()]
    .sort((a, b) => Number(b.active) - Number(a.active) || a.name.localeCompare(b.name))
    .slice(0, Math.max(400, currentItems.length));
}

async function seedCanteenDefaults(canteenId, canteenName = "Main Canteen", businessCategory = "Canteen") {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  if (!(await allMenuItems(targetCanteenId, { includeHidden: true })).length) {
    for (const item of defaultMenuForBusinessCategory(businessCategory)) {
      await saveMenuItem({ ...item, canteenId: targetCanteenId });
    }
  }
  const kind = shopKindFromCategory(businessCategory);
  if (kind === "canteen" && !(await allStockItems(targetCanteenId)).length) {
    for (const item of defaultStockItems) {
      await saveStockItem({ ...item, canteenId: targetCanteenId });
    }
  }
  const posMode = posModeForCategory(businessCategory);
  await saveSettings({ ...defaultSettings, canteenName, businessCategory, posMode }, targetCanteenId);
  await sanitizeMenuForBusinessCategory(targetCanteenId, businessCategory, posMode);
}

async function allStockItems(canteenId = DEFAULT_CANTEEN_ID) {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  if (!mongoReady) return memory.stockItems.filter(item => normalizeCanteenId(item.canteenId || DEFAULT_CANTEEN_ID) === targetCanteenId);
  return StockItem.find({ canteenId: targetCanteenId }).sort({ id: 1, createdAt: 1 }).lean();
}

async function saveStockItem(payload) {
  const canteenId = normalizeCanteenId(payload.canteenId || DEFAULT_CANTEEN_ID);
  const current = await allStockItems(canteenId);
  const item = {
    id: payload.id ? Number(payload.id) : nextId(current),
    canteenId,
    item: String(payload.item || "").trim(),
    stock: Number(payload.stock || 0),
    unit: payload.unit || "Unit",
    minStock: Number(payload.minStock || 0)
  };

  if (!item.item) throw new Error("Stock item is required");

  if (!mongoReady) {
    const existing = memory.stockItems.find(row =>
      normalizeCanteenId(row.canteenId || DEFAULT_CANTEEN_ID) === canteenId &&
      Number(row.id) === Number(item.id)
    );
    if (existing) Object.assign(existing, item);
    else memory.stockItems.push(item);
    return item;
  }

  return modelToPlain(await StockItem.findOneAndUpdate(
    { canteenId, id: item.id },
    { $set: item },
    { new: true, upsert: true }
  ));
}

async function allStockUsage(canteenId = DEFAULT_CANTEEN_ID) {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  const byNewest = (a, b) => String(b.date || "").localeCompare(String(a.date || "")) || Number(b.id || 0) - Number(a.id || 0);
  if (!mongoReady) return memory.stockUsage.filter(item => normalizeCanteenId(item.canteenId || DEFAULT_CANTEEN_ID) === targetCanteenId).sort(byNewest);
  return StockUsage.find({ canteenId: targetCanteenId }).sort({ date: -1, createdAt: -1 }).lean();
}

async function saveStockUsage(payload, actor = {}) {
  const canteenId = normalizeCanteenId(payload.canteenId || DEFAULT_CANTEEN_ID);
  const current = await allStockUsage(canteenId);
  const stockItems = await allStockItems(canteenId);
  const source = stockItems.find(item => Number(item.id) === Number(payload.itemId)) || stockItems.find(item => String(item.item || "").toLowerCase() === String(payload.item || "").toLowerCase());
  const qtyUsed = Math.max(0, Number(payload.qtyUsed || 0));
  const usage = {
    id: payload.id ? Number(payload.id) : nextId(current),
    canteenId,
    itemId: source ? Number(source.id) : Number(payload.itemId || 0),
    item: source ? source.item : String(payload.item || "").trim(),
    qtyUsed,
    unit: payload.unit || source?.unit || "Unit",
    date: payload.date || new Date().toISOString().slice(0, 10),
    storeKeeper: payload.storeKeeper || actor.name || "Store Keeper",
    note: String(payload.note || "").trim()
  };

  if (!usage.item) throw new Error("Stock item is required");
  if (usage.qtyUsed <= 0) throw new Error("Used quantity is required");

  if (!mongoReady) {
    memory.stockUsage.unshift(usage);
    if (source) source.stock = Math.max(0, Number(source.stock || 0) - usage.qtyUsed);
    return usage;
  }

  const saved = await StockUsage.findOneAndUpdate(
    { canteenId, id: usage.id },
    { $set: usage },
    { new: true, upsert: true }
  ).lean();
  if (source) {
    await StockItem.findOneAndUpdate(
      { canteenId, id: Number(source.id) },
      { $set: { stock: Math.max(0, Number(source.stock || 0) - usage.qtyUsed) } }
    );
  }
  return saved;
}

async function allExpenses(canteenId = DEFAULT_CANTEEN_ID) {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  if (!mongoReady) return memory.expenses.filter(item => normalizeCanteenId(item.canteenId || DEFAULT_CANTEEN_ID) === targetCanteenId);
  return Expense.find({ canteenId: targetCanteenId }).sort({ createdAt: 1 }).lean();
}

async function saveExpense(payload) {
  const canteenId = normalizeCanteenId(payload.canteenId || DEFAULT_CANTEEN_ID);
  const current = await allExpenses(canteenId);
  const expense = {
    id: payload.id ? Number(payload.id) : nextId(current),
    canteenId,
    title: String(payload.title || "").trim(),
    amount: Number(payload.amount || 0),
    category: payload.category || "General",
    time: payload.time || new Date().toLocaleString("en-IN", { timeZone: INDIA_TZ })
  };

  if (!expense.title) throw new Error("Expense title is required");

  if (!mongoReady) {
    const existing = memory.expenses.find(row =>
      normalizeCanteenId(row.canteenId || DEFAULT_CANTEEN_ID) === canteenId &&
      Number(row.id) === Number(expense.id)
    );
    if (existing) Object.assign(existing, expense);
    else memory.expenses.push(expense);
    return expense;
  }

  return modelToPlain(await Expense.findOneAndUpdate(
    { canteenId, id: expense.id },
    { $set: expense },
    { new: true, upsert: true }
  ));
}

async function getSettings(canteenId = DEFAULT_CANTEEN_ID) {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  const core = await getCoreCanteen(targetCanteenId).catch(() => null);
  const coreCategory = core?.businessCategory || "";
  if (!mongoReady) {
    const merged = { ...defaultSettings, ...memory.settings, canteenId: targetCanteenId };
    if (coreCategory && (!merged.businessCategory || merged.businessCategory === defaultSettings.businessCategory)) merged.businessCategory = coreCategory;
    if (String(merged.businessCategory || merged.posMode || "").toLowerCase().match(/chicken|meat|mutton|fish/)) merged.posMode = "chicken_shop";
    return merged;
  }
  const stored = await ReportSetting.findOne({ key: "app", canteenId: targetCanteenId }).lean();
  const legacy = !stored && targetCanteenId === DEFAULT_CANTEEN_ID
    ? await ReportSetting.findOne({ key: "app", canteenId: { $exists: false } }).lean()
    : null;
  const merged = { ...defaultSettings, canteenId: targetCanteenId, ...(stored || legacy || {}) };
  if (coreCategory && (!merged.businessCategory || merged.businessCategory === defaultSettings.businessCategory)) merged.businessCategory = coreCategory;
  if (shopKindFromCategory(merged.businessCategory, merged.posMode) === "chicken") merged.posMode = "chicken_shop";
  return merged;
}

function parseReportTime(value) {
  const raw = String(value || "").trim();
  const match24 = raw.match(/^([01]?\d|2[0-3]):([0-5]\d)$/);
  if (match24) return `${match24[1].padStart(2, "0")}:${match24[2]}`;

  const match12 = raw.match(/^(\d{1,2}):([0-5]\d)\s*(AM|PM)$/i);
  if (!match12) return "22:00";

  let hour = Number(match12[1]);
  const minute = match12[2];
  const suffix = match12[3].toUpperCase();
  if (suffix === "PM" && hour < 12) hour += 12;
  if (suffix === "AM" && hour === 12) hour = 0;
  return `${String(hour).padStart(2, "0")}:${minute}`;
}

async function saveSettings(payload, canteenId = DEFAULT_CANTEEN_ID) {
  const targetCanteenId = normalizeCanteenId(canteenId || payload.canteenId || DEFAULT_CANTEEN_ID);
  const next = { ...payload };
  if(Object.hasOwn(next,'taxSettings')) next.taxSettings=BillTaxes.normalize(next.taxSettings);
  if (Object.prototype.hasOwnProperty.call(next, "autoReport")) {
    next.autoReport = next.autoReport === true || next.autoReport === "true";
  }
  if (Object.prototype.hasOwnProperty.call(next, "receiptArea")) next.receiptArea = String(next.receiptArea || "").replace(/[\r\n\x00-\x1f]/g, " ").trim().slice(0, 100);
  if (next.reportTime) next.reportTime = parseReportTime(next.reportTime);
  if (Object.prototype.hasOwnProperty.call(next, "receiptLogoSize")) {
    next.receiptLogoSize = Math.max(60, Math.min(160, Number(next.receiptLogoSize || 100)));
  }
  if (next.adminWhatsAppNumber) next.reportPhone = next.adminWhatsAppNumber;
  if (next.reportPhone && !next.adminWhatsAppNumber) next.adminWhatsAppNumber = next.reportPhone;

  if (!mongoReady) {
    memory.settings = { ...memory.settings, ...next, canteenId: targetCanteenId };
    return memory.settings;
  }

  const saved = await ReportSetting.findOneAndUpdate(
    { key: "app", canteenId: targetCanteenId },
    { $set: { ...next, key: "app", canteenId: targetCanteenId } },
    { new: true, upsert: true }
  ).lean();
  return { ...defaultSettings, ...saved, canteenId: targetCanteenId };
}

async function allUsers() {
  if (!mongoReady) return memory.users;
  return User.find({}).sort({ createdAt: 1 }).lean();
}

async function saveUser(payload) {
  const user = {
    id: payload.id ? Number(payload.id) : nextId(await allUsers()),
    canteenId: normalizeCanteenId(payload.canteenId || DEFAULT_CANTEEN_ID),
    name: payload.name || "User",
    mobile: normalizeMobile(payload.mobile),
    password: String(payload.password || "1234"),
    role: CANTEEN_ROLES.includes(payload.role) ? payload.role : "user",
    branchAddress: String(payload.branchAddress || "").trim(),
    active: payload.active !== false,
    mustChangePassword: payload.mustChangePassword === true
  };

  if (!user.mobile) throw new Error("Mobile is required");

  if (!mongoReady) {
    const existing = memory.users.find(row =>
      normalizeCanteenId(row.canteenId || DEFAULT_CANTEEN_ID) === user.canteenId &&
      row.mobile === user.mobile
    );
    if (existing) Object.assign(existing, user);
    else memory.users.push(user);
    return user;
  }

  return modelToPlain(await User.findOneAndUpdate(
    { canteenId: user.canteenId, mobile: user.mobile },
    { $set: user },
    { new: true, upsert: true }
  ));
}

async function deleteUser(mobile, canteenId = DEFAULT_CANTEEN_ID) {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  if (!mongoReady) {
    memory.users = memory.users.filter(user =>
      normalizeCanteenId(user.canteenId || DEFAULT_CANTEEN_ID) !== targetCanteenId ||
      user.mobile !== mobile
    );
    return;
  }
  await User.deleteOne({ canteenId: targetCanteenId, mobile });
}

async function allBranchAddresses(canteenId = DEFAULT_CANTEEN_ID) {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  const byName = (a, b) => String(a.name || "").localeCompare(String(b.name || ""));
  if (!mongoReady) {
    return memory.branchAddresses
      .filter(item => normalizeCanteenId(item.canteenId || DEFAULT_CANTEEN_ID) === targetCanteenId)
      .filter(item => item.active !== false)
      .sort(byName);
  }
  return (await BranchAddress.find({ canteenId: targetCanteenId, active: { $ne: false } }).lean()).sort(byName);
}

async function saveBranchAddress(payload) {
  const canteenId = normalizeCanteenId(payload.canteenId || DEFAULT_CANTEEN_ID);
  const current = await allBranchAddresses(canteenId);
  const address = {
    id: payload.id ? Number(payload.id) : nextId(current),
    canteenId,
    name: String(payload.name || "").trim(),
    address: String(payload.address || "").trim(),
    active: payload.active !== false
  };
  if (!address.name) throw new Error("Address name is required");
  if (!mongoReady) {
    const existing = memory.branchAddresses.find(row =>
      normalizeCanteenId(row.canteenId || DEFAULT_CANTEEN_ID) === canteenId &&
      Number(row.id) === Number(address.id)
    );
    if (existing) Object.assign(existing, address);
    else memory.branchAddresses.push(address);
    return address;
  }
  return modelToPlain(await BranchAddress.findOneAndUpdate(
    { canteenId, id: address.id },
    { $set: address },
    { new: true, upsert: true }
  ));
}

function makeOrder(payload) {
  const total = Number(payload.total || 0);
  const paymentBreakup = normalizePaymentBreakup(payload.paymentBreakup, payload.payment, total);
  return {
    createdAt:payload.createdAt && Number.isFinite(Date.parse(payload.createdAt)) ? new Date(payload.createdAt) : new Date(),
    taxes:payload.taxes||[],charges:payload.charges||[],taxTotal:Number(payload.taxTotal||0),taxableAmount:payload.taxableAmount,taxSettings:payload.taxSettings,gstin:payload.gstin||'',receiptFields:payload.receiptFields,
    canteenId: normalizeCanteenId(payload.canteenId || DEFAULT_CANTEEN_ID),
    id: payload.id || Date.now(),
    clientOrderId: payload.clientOrderId,
    time: payload.time || new Date().toLocaleString("en-IN", { timeZone: INDIA_TZ }),
    canteen: payload.canteen || "Main Canteen",
    cashier: payload.cashier || "Mobile Cashier",
    cashierMobile: String(payload.cashierMobile || payload.userMobile || "").trim(),
    branchAddress: String(payload.branchAddress || "").trim(),
    payment: payload.payment || "Cash",
    paymentBreakup,
    creditName: payload.creditName || "",
    subtotal: Number(payload.subtotal || total),
    discount: Number(payload.discount || 0),
    total,
    items: Array.isArray(payload.items) ? payload.items : [],
    syncedAt: new Date().toISOString()
  };
}

function normalizePaymentBreakup(value, payment, total) {
  const source = value && typeof value === "object" ? value : {};
  if (payment === "Split") {
    let cash = Math.max(0, Number(source.cash || 0));
    let online = Math.max(0, Number(source.online || 0));
    let credit = Math.max(0, Number(source.credit || 0));
    const splitTotal = cash + online + credit;
    if (total >= 0 && Math.round(splitTotal * 100) !== Math.round(total * 100)) {
      cash = Math.min(cash, total);
      credit = Math.min(credit, Math.max(0, total - cash));
      online = Math.max(0, total - cash - credit);
    }
    return { cash, online, credit };
  }
  if (payment === "Online" || payment === "Card") return { cash: 0, online: total, credit: 0 };
  if (payment === "Credit") return { cash: 0, online: 0, credit: total };
  if (payment === "Cancel") return { cash: 0, online: 0, credit: 0 };
  return { cash: total, online: 0, credit: 0 };
}

async function saveOrder(payload, dineIn = false) {
  if(payload.taxSettings && !dineIn && payload.payment!=='Cancel') {
    const calculated=BillTaxes.calculate(Number(payload.subtotal),Number(payload.discount||0),payload.taxSettings);
    if(Math.abs(calculated.total-Number(payload.total))>0.001) throw Error('Bill total does not match discount and taxes');
    payload={...payload,...calculated};
  }
  const order = makeOrder(payload);
  if (dineIn) {
    for (const key of ["orderType", "tableId", "tableName", "dineSessionId", "kitchenTickets"]) order[key] = payload[key];
  }

  if (!mongoReady) {
    const exists = memory.orders.find(row =>
      normalizeCanteenId(row.canteenId || DEFAULT_CANTEEN_ID) === order.canteenId &&
      ((order.clientOrderId && row.clientOrderId === order.clientOrderId) || Number(row.id) === Number(order.id))
    );
    if (exists) return exists;
    memory.orders.push(order);
    memory.sales.push({ ...order, orderId: order.id });
    return order;
  }

  const filter = order.clientOrderId
    ? { canteenId: order.canteenId, clientOrderId: order.clientOrderId }
    : { canteenId: order.canteenId, id: order.id };
  const saved = await Order.findOneAndUpdate(
    filter,
    { $setOnInsert: order },
    { new: true, upsert: true }
  ).lean();

  await Sale.findOneAndUpdate(
    order.clientOrderId
      ? { canteenId: order.canteenId, clientOrderId: order.clientOrderId }
      : { canteenId: order.canteenId, orderId: order.id },
    { $setOnInsert: { ...order, orderId: order.id } },
    { new: true, upsert: true }
  );

  return saved;
}

async function allOrders(canteenId = DEFAULT_CANTEEN_ID) {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  if (!mongoReady) return memory.orders.filter(item => normalizeCanteenId(item.canteenId || DEFAULT_CANTEEN_ID) === targetCanteenId);
  return Order.find({ canteenId: targetCanteenId }).sort({ createdAt: 1 }).lean();
}

async function getCoreCanteen(canteenId = DEFAULT_CANTEEN_ID) {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  if (!mongoReady) return memory.canteens.find(item => normalizeCanteenId(item.canteenId) === targetCanteenId) || null;
  return Canteen.findOne({ canteenId: targetCanteenId }).lean();
}

async function clearOrders(canteenId = DEFAULT_CANTEEN_ID) {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  if (!mongoReady) {
    memory.orders = memory.orders.filter(order => normalizeCanteenId(order.canteenId || DEFAULT_CANTEEN_ID) !== targetCanteenId);
    memory.sales = memory.sales.filter(sale => normalizeCanteenId(sale.canteenId || DEFAULT_CANTEEN_ID) !== targetCanteenId);
    return;
  }
  await Promise.all([Order.deleteMany({ canteenId: targetCanteenId }), Sale.deleteMany({ canteenId: targetCanteenId })]);
}

async function deleteOrder(id, canteenId = DEFAULT_CANTEEN_ID) {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  const key = String(id || "").trim();
  if (!key) throw new Error("Order id is required");
  const numericId = Number(key);
  const numericMatch = Number.isFinite(numericId) ? numericId : -1;

  if (!mongoReady) {
    memory.orders = memory.orders.filter(order =>
      normalizeCanteenId(order.canteenId || DEFAULT_CANTEEN_ID) !== targetCanteenId ||
      (String(order.clientOrderId || "") !== key && Number(order.id) !== numericMatch)
    );
    memory.sales = memory.sales.filter(sale =>
      normalizeCanteenId(sale.canteenId || DEFAULT_CANTEEN_ID) !== targetCanteenId ||
      (String(sale.clientOrderId || "") !== key && Number(sale.orderId) !== numericMatch)
    );
    return;
  }

  await Promise.all([
    Order.deleteOne({ canteenId: targetCanteenId, $or: [{ clientOrderId: key }, { id: numericMatch }] }),
    Sale.deleteOne({ canteenId: targetCanteenId, $or: [{ clientOrderId: key }, { orderId: numericMatch }] })
  ]);
}

function indiaParts(date = new Date()) {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: INDIA_TZ,
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false
  }).formatToParts(date);
  return Object.fromEntries(parts.map(part => [part.type, part.value]));
}

function indiaDateKey(date = new Date()) {
  const parts = indiaParts(date);
  return `${parts.day}-${parts.month}-${parts.year}`;
}

function indiaTimeKey(date = new Date()) {
  const parts = indiaParts(date);
  return `${parts.hour}:${parts.minute}`;
}

function orderDate(order) {
  if (order.createdAt) return new Date(order.createdAt);
  if (order.syncedAt) return new Date(order.syncedAt);
  if (Number(order.id)) return new Date(Number(order.id));
  return new Date(order.time || Date.now());
}

function reportOrdersForType(orders, reportType) {
  const now = new Date();
  const todayKey = indiaDateKey(now);
  if (reportType === "yearly") {
    const currentYear = todayKey.slice(6);
    return orders.filter(order => indiaDateKey(orderDate(order)).slice(6) === currentYear);
  }
  if (reportType === "monthly") {
    const currentMonth = todayKey.slice(3);
    return orders.filter(order => indiaDateKey(orderDate(order)).slice(3) === currentMonth);
  }
  if (reportType === "weekly") {
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    return orders.filter(order => orderDate(order) >= weekAgo);
  }
  return orders.filter(order => indiaDateKey(orderDate(order)) === todayKey);
}

function topItemsFromOrders(orders) {
  const counts = new Map();
  orders.forEach(order => (order.items || []).forEach(item => {
    const key = item.name || "Item";
    const current = counts.get(key) || { name: key, qty: 0, total: 0 };
    current.qty += Number(item.qty || item.grams || 0);
    current.total += Number(item.lineTotal ?? (Number(item.qty || 0) * Number(item.price || 0)));
    counts.set(key, current);
  }));
  return [...counts.values()].sort((a, b) => b.qty - a.qty);
}

function paymentTotals(orders) {
  return orders.reduce((totals, order) => {
    const amount = Number(order.total || 0);
    totals.totalSales += amount;
    const breakup = normalizePaymentBreakup(order.paymentBreakup, order.payment, amount);
    totals.cash += Number(breakup.cash || 0);
    totals.upi += Number(breakup.online || 0);
    totals.credit += Number(breakup.credit || 0);
    totals.online = totals.upi + totals.card;
    return totals;
  }, { totalSales: 0, cash: 0, upi: 0, card: 0, online: 0, credit: 0 });
}

function userSalesFromOrders(orders) {
  const rows = new Map();
  orders.forEach(order => {
    const key = order.cashier || "Unknown";
    const row = rows.get(key) || { user: key, orders: 0, total: 0, cash: 0, online: 0, credit: 0 };
    const amount = Number(order.total || 0);
    const breakup = normalizePaymentBreakup(order.paymentBreakup, order.payment, amount);
    row.orders += 1;
    row.total += amount;
    row.cash += Number(breakup.cash || 0);
    row.online += Number(breakup.online || 0);
    row.credit += Number(breakup.credit || 0);
    rows.set(key, row);
  });
  return [...rows.values()].sort((a, b) => b.total - a.total);
}

async function reportData(reportType = "daily", canteenId = DEFAULT_CANTEEN_ID) {
  const currentOrders = reportOrdersForType(await allOrders(canteenId), reportType);
  const currentExpenses = await allExpenses(canteenId);
  const currentStock = await allStockItems(canteenId);
  const totals = paymentTotals(currentOrders);
  const totalExpenses = currentExpenses.reduce((sum, expense) => sum + Number(expense.amount || 0), 0);
  return {
    orders: currentOrders,
    expenses: currentExpenses,
    stock: currentStock,
    totalExpenses,
    topItems: topItemsFromOrders(currentOrders),
    lowStock: currentStock.filter(item => Number(item.stock || 0) <= Number(item.minStock || 0)),
    ...totals,
    netCollection: totals.totalSales - totalExpenses
  };
}

async function buildWhatsAppReport(reportType = "daily", canteenId = DEFAULT_CANTEEN_ID) {
  const data = await reportData(reportType, canteenId);
  const appSettings = await getSettings(canteenId);
  const titleType = reportType[0].toUpperCase() + reportType.slice(1);
  const topLines = data.topItems.slice(0, 3).length
    ? data.topItems.slice(0, 3).map((item, index) => `${index + 1}. ${item.name} - ${item.qty}`).join("\n")
    : "No items sold";
  const stockLines = data.lowStock.length
    ? data.lowStock.map(item => `- ${item.item} low`).join("\n")
    : "- No low stock";

  return [
    `🍽 ${appSettings.canteenName || "axzen Canteen"} ${titleType} Report`,
    `📅 Date: ${indiaDateKey()}`,
    "",
    `💰 Total Sale: ₹${data.totalSales.toFixed(0)}`,
    `💵 Cash: ₹${data.cash.toFixed(0)}`,
    `📱 Online: ₹${data.online.toFixed(0)}`,
    `🧾 Total Orders: ${data.orders.length}`,
    "",
    "Top Items:",
    topLines,
    "",
    `Expenses: ₹${data.totalExpenses.toFixed(0)}`,
    `Net Collection: ₹${data.netCollection.toFixed(0)}`,
    "",
    "Stock Alerts:",
    stockLines
  ].join("\n");
}

async function addWhatsAppLog(entry) {
  const log = {
    time: new Date().toISOString(),
    ...entry,
    canteenId: normalizeCanteenId(entry.canteenId || DEFAULT_CANTEEN_ID)
  };
  if (!mongoReady) {
    memory.whatsappLogs.unshift(log);
    memory.whatsappLogs = memory.whatsappLogs.slice(0, 100);
  } else {
    await WhatsappLog.create(log);
  }
  const state = log.success ? "sent success" : `failed: ${log.error}`;
  console.log(`WhatsApp report ${state} | to=${log.to || "-"} | time=${log.time}`);
  return log;
}

async function allWhatsappLogs() {
  return allWhatsappLogsForCanteen(DEFAULT_CANTEEN_ID);
}

async function allWhatsappLogsForCanteen(canteenId = DEFAULT_CANTEEN_ID) {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  if (!mongoReady) {
    return memory.whatsappLogs.filter(item => normalizeCanteenId(item.canteenId || DEFAULT_CANTEEN_ID) === targetCanteenId);
  }
  return WhatsappLog.find({ canteenId: targetCanteenId }).sort({ createdAt: -1 }).limit(100).lean();
}

async function allMarketingUsers() {
  if (!mongoReady) return memory.marketingUsers;
  return MarketingUser.find({}).sort({ createdAt: 1 }).lean();
}

async function saveMarketingUser(payload, actor) {
  const current = await allMarketingUsers();
  const existingEmployee = current.find(item => String(item.employeeId || "").toUpperCase() === String(payload.employeeId || "").trim().toUpperCase()) || {};
  const employee = {
    employeeId: String(payload.employeeId || existingEmployee.employeeId || "").trim().toUpperCase(),
    name: String(payload.name ?? existingEmployee.name ?? "").trim(),
    mobile: normalizeMobile(payload.mobile ?? existingEmployee.mobile ?? ""),
    aadhaarNumber: String(payload.aadhaarNumber ?? existingEmployee.aadhaarNumber ?? "").trim(),
    panNumber: String(payload.panNumber ?? existingEmployee.panNumber ?? "").trim().toUpperCase(),
    bankAccountName: String(payload.bankAccountName ?? existingEmployee.bankAccountName ?? "").trim(),
    bankAccountNumber: String(payload.bankAccountNumber ?? existingEmployee.bankAccountNumber ?? "").replace(/\D/g, ""),
    bankIfsc: String(payload.bankIfsc ?? existingEmployee.bankIfsc ?? "").trim().toUpperCase(),
    bankUpi: String(payload.bankUpi ?? existingEmployee.bankUpi ?? "").trim(),
    password: String(payload.password ?? existingEmployee.password ?? "1234"),
    role: payload.role ? (["super_admin", "manager"].includes(payload.role) ? payload.role : "marketing") : (existingEmployee.role || "marketing"),
    department: ["Marketing", "Sales", "Operations", "Help Center"].includes(payload.department) ? payload.department : (existingEmployee.department || "Marketing"),
    active: payload.active !== undefined ? payload.active !== false : existingEmployee.active !== false,
    target: Number(payload.target ?? existingEmployee.target ?? 0),
    updatedAt: new Date().toISOString()
  };

  if (employee.department === "Help Center") {
    employee.role = "marketing";
    if (String(employee.mobile || "").replace(/\D/g, "").length < 10) throw new Error("Help Center employees need a phone number for login.");
  }
  if (!employee.employeeId || !employee.name) throw new Error("Employee ID and name are required");
  if (!/^[A-Z0-9_-]{3,24}$/.test(employee.employeeId)) throw new Error("Employee ID must be 3-24 letters or numbers");
  if (employee.aadhaarNumber && !/^\d{12}$/.test(employee.aadhaarNumber)) throw new Error("Aadhaar number must be 12 digits");
  if (employee.panNumber && !/^[A-Z]{5}\d{4}[A-Z]$/.test(employee.panNumber)) throw new Error("PAN number format is invalid");

  if (!mongoReady) {
    const existing = memory.marketingUsers.find(item => String(item.employeeId).toUpperCase() === employee.employeeId);
    if (existing) Object.assign(existing, employee);
    else memory.marketingUsers.push({ ...employee, createdAt: new Date().toISOString() });
  } else {
    await MarketingUser.findOneAndUpdate(
      { employeeId: employee.employeeId },
      { $set: employee, $setOnInsert: { createdAt: new Date().toISOString() } },
      { new: true, upsert: true }
    );
  }

  await addMarketingActivity({
    type: "employee",
    text: `${employee.name} employee profile saved`,
    actor: actor?.name || "Super Admin"
  });
  return (await allMarketingUsers()).find(item => String(item.employeeId).toUpperCase() === employee.employeeId);
}

async function allMarketingCanteens() {
  if (!mongoReady) return memory.marketingCanteens;
  return MarketingCanteen.find({}).sort({ createdAt: -1 }).lean();
}

async function addMarketingActivity(activity) {
  const entry = {
    id: Date.now(),
    type: activity.type || "update",
    text: activity.text,
    actor: activity.actor || "System",
    canteenId: activity.canteenId,
    createdAt: new Date().toISOString()
  };
  if (!mongoReady) {
    memory.marketingActivities.unshift(entry);
    memory.marketingActivities = memory.marketingActivities.slice(0, 100);
    return entry;
  }
  return MarketingActivity.create(entry);
}

async function allMarketingActivities() {
  if (!mongoReady) return memory.marketingActivities;
  return MarketingActivity.find({}).sort({ createdAt: -1 }).limit(100).lean();
}

async function allMarketingPayments() {
  if (!mongoReady) return memory.marketingPayments;
  return MarketingPayment.find({}).sort({ createdAt: -1 }).limit(500).lean();
}

async function allSubscriptionOrders() {
  if (!mongoReady) return memory.subscriptionOrders;
  return SubscriptionOrder.find({}).sort({ createdAt: -1 }).limit(500).lean();
}

async function saveSubscriptionOrder(entry) {
  const payload = { ...entry, updatedAt: new Date().toISOString() };
  if (!mongoReady) {
    const index = memory.subscriptionOrders.findIndex(item => item.orderId === payload.orderId);
    if (index >= 0) memory.subscriptionOrders[index] = { ...memory.subscriptionOrders[index], ...payload };
    else memory.subscriptionOrders.unshift({ ...payload, createdAt: new Date().toISOString() });
    return memory.subscriptionOrders.find(item => item.orderId === payload.orderId);
  }
  return SubscriptionOrder.findOneAndUpdate(
    { orderId: payload.orderId },
    { $set: payload, $setOnInsert: { createdAt: new Date().toISOString() } },
    { new: true, upsert: true }
  ).lean();
}

async function findSubscriptionOrder(orderId) {
  if (!orderId) return null;
  if (!mongoReady) return memory.subscriptionOrders.find(item => item.orderId === orderId) || null;
  return SubscriptionOrder.findOne({ orderId }).lean();
}

async function addMarketingPayment(payment) {
  const entry = {
    id: Date.now(),
    canteenId: Number(payment.canteenId),
    canteenName: payment.canteenName,
    amount: Number(payment.amount || 0),
    pendingAmount: Number(payment.pendingAmount || 0),
    paymentMode: payment.paymentMode || "UPI",
    paymentReference: payment.paymentReference || "",
    notes: payment.notes || "",
    collectedBy: payment.collectedBy || "",
    collectedByName: payment.collectedByName || "",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  if (!entry.amount && !entry.pendingAmount) return null;
  if (!mongoReady) {
    memory.marketingPayments.unshift(entry);
    return entry;
  }
  return MarketingPayment.create(entry);
}

async function allMarketingSupportTickets() {
  if (!mongoReady) return memory.supportTickets;
  return MarketingSupportTicket.find({}).sort({ createdAt: -1 }).limit(200).lean();
}

async function allAppReleases() {
  if (!mongoReady) return [];
  return AppRelease.find({}).select("-bundle").sort({ createdAt: -1 }).limit(50).lean();
}

async function helpTicketsForCanteen(canteenId) {
  const target = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  if (!mongoReady) return memory.supportTickets.filter(item => normalizeCanteenId(item.canteenId) === target).sort(byNewest);
  return MarketingSupportTicket.find({ canteenId: target }).sort({ createdAt: -1 }).limit(100).lean();
}

async function allEnquiries() {
  if (!mongoReady) return memory.enquiries;
  return Enquiry.find({}).sort({ createdAt: -1 }).limit(500).lean();
}

async function allWebsitePlans({ activeOnly = false } = {}) {
  const filter = activeOnly ? { active: { $ne: false } } : {};
  if (!mongoReady) {
    return memory.websitePlans
      .filter(item => !activeOnly || item.active !== false)
      .sort((a, b) => Number(a.sortOrder || a.id || 0) - Number(b.sortOrder || b.id || 0));
  }
  return WebsitePlan.find(filter).sort({ sortOrder: 1, id: 1 }).lean();
}

function numericPrice(value) {
  const text = String(value || "").replace(/[^0-9.]/g, "");
  return Number(text || 0);
}

async function subscriptionStatusForCanteen(canteenId, requestedPlanName = "") {
  const targetCanteenId = normalizeCanteenId(canteenId || DEFAULT_CANTEEN_ID);
  const marketing = (await allMarketingCanteens()).find(item => normalizeCanteenId(item.activatedCanteenId) === targetCanteenId) || null;
  const core = await getCoreCanteen(targetCanteenId);
  const plans = await allWebsitePlans({ activeOnly: true });
  const findPlan = name => plans.find(plan => String(plan.name || "").trim().toLowerCase() === String(name || "").trim().toLowerCase());
  const currentPlanName = marketing?.selectedPlan || core?.plan || "Professional";
  const currentPlan = findPlan(currentPlanName)
    || findPlan("professional")
    || plans[0]
    || { name: "Professional", offerPrice: "999" };
  const requestedPlan = requestedPlanName ? findPlan(requestedPlanName) : null;
  if (requestedPlanName && (!requestedPlan || !numericPrice(requestedPlan.offerPrice))) {
    throw new Error("This plan needs the sales team. Please contact Axzen sales.");
  }
  const selectedPlan = requestedPlan || currentPlan;
  const selectedPlanName = selectedPlan.name || currentPlanName;
  const monthlyPrice = numericPrice(selectedPlan.offerPrice) || 999;
  const durations = [1, 3, 6, 9, 12].map(months => ({
    months,
    label: `${months} Month${months > 1 ? "s" : ""}`,
    amount: monthlyPrice * months
  }));
  const expiryDate = marketing?.planExpiryDate || "";
  const expiryMs = expiryDate ? new Date(`${String(expiryDate).slice(0, 10)}T23:59:59+05:30`).getTime() : NaN;
  const daysRemaining = Number.isNaN(expiryMs) ? null : Math.ceil((expiryMs - Date.now()) / 86400000);
  return {
    canteenId: targetCanteenId,
    canteenName: marketing?.canteenName || core?.name || "",
    marketingCanteenId: marketing?.id || 0,
    printerModel: marketing?.printerModel || "",
    printerSerialNumber: marketing?.printerSerialNumber || "",
    planName: selectedPlanName || "Professional",
    currentPlanName: currentPlan.name || currentPlanName,
    planType: marketing?.planType || (core?.paymentStatus === "paid" ? "Paid" : "Trial"),
    monthlyPrice,
    plans: plans.map(plan => ({
      name: plan.name,
      description: plan.description || "",
      monthlyPrice: numericPrice(plan.offerPrice),
      originalPrice: numericPrice(plan.originalPrice),
      priceLabel: numericPrice(plan.offerPrice) ? "" : String(plan.offerPrice || "Custom Pricing"),
      badge: plan.badge || "",
      popular: plan.popular === true,
      features: Array.isArray(plan.features) ? plan.features.filter(Boolean) : []
    })),
    expiryDate,
    status: marketing?.status || (core?.active === false ? "Blocked" : "Active"),
    expired: isPastDate(expiryDate),
    daysRemaining,
    expiresSoon: daysRemaining !== null && daysRemaining >= 0 && daysRemaining <= 2,
    takeawayEnabled: marketing?.takeawayEnabled !== false,
    durations
  };
}

function cashfreeConfigured() {
  return Boolean(process.env.CASHFREE_CLIENT_ID && process.env.CASHFREE_CLIENT_SECRET);
}

function verifyCashfreeWebhookSignature(req) {
  const signature = String(req.headers["x-webhook-signature"] || "");
  const timestamp = String(req.headers["x-webhook-timestamp"] || "");
  const secret = process.env.CASHFREE_CLIENT_SECRET;
  if (!secret) throw new Error("Cashfree webhook secret missing");
  if (!signature || !timestamp || !req.rawBody) throw new Error("Cashfree webhook signature headers missing");
  const expected = crypto.createHmac("sha256", secret).update(timestamp + req.rawBody).digest("base64");
  const receivedBuffer = Buffer.from(signature);
  const expectedBuffer = Buffer.from(expected);
  if (receivedBuffer.length !== expectedBuffer.length || !crypto.timingSafeEqual(receivedBuffer, expectedBuffer)) {
    throw new Error("Cashfree webhook signature mismatch");
  }
}

function cashfreeWebhookOrderId(payload) {
  const data = payload?.data || payload || {};
  return String(
    data?.order?.order_id ||
    data?.order_id ||
    data?.payment?.order_id ||
    payload?.order_id ||
    ""
  ).trim();
}

function cashfreeWebhookPaymentStatus(payload) {
  const data = payload?.data || payload || {};
  return String(
    data?.payment?.payment_status ||
    data?.payment?.status ||
    data?.order?.order_status ||
    data?.order_status ||
    payload?.payment_status ||
    payload?.type ||
    ""
  ).toUpperCase();
}

async function cashfreeRequest(pathname, options = {}) {
  if (!cashfreeConfigured()) throw new Error("Cashfree keys missing on server");
  if (typeof fetch !== "function") throw new Error("Server fetch API unavailable");
  const response = await fetch(`${CASHFREE_API_BASE}${pathname}`, {
    method: options.method || "GET",
    headers: {
      "Content-Type": "application/json",
      "Accept": "application/json",
      "X-Client-Id": process.env.CASHFREE_CLIENT_ID,
      "X-Client-Secret": process.env.CASHFREE_CLIENT_SECRET,
      "x-api-version": CASHFREE_API_VERSION,
      ...(options.headers || {})
    },
    body: options.body ? JSON.stringify(options.body) : undefined
  });
  const text = await response.text();
  let body = {};
  try { body = text ? JSON.parse(text) : {}; } catch { body = { message: text }; }
  if (!response.ok) {
    throw new Error(body.message || body.error_description || body.error || `Cashfree request failed ${response.status}`);
  }
  return body;
}

async function createSubscriptionCashfreeOrder(canteenId, months, user, req, planName = "") {
  const status = await subscriptionStatusForCanteen(canteenId, planName);
  const selected = status.durations.find(item => Number(item.months) === Number(months));
  if (!selected) throw new Error("Select 1, 3, 6, 9, or 12 months");
  const amount = Number(selected.amount || 0);
  if (amount <= 0) throw new Error("Recharge amount is invalid");
  const orderId = `AXZEN_${status.canteenId}_${Date.now()}_${Math.random().toString(16).slice(2, 8)}`.replace(/[^A-Z0-9_]/g, "_");
  const returnBase = process.env.CASHFREE_RETURN_URL || process.env.PUBLIC_APP_URL || `${req.protocol}://${req.get("host")}/mobile`;
  const order = await cashfreeRequest("/orders", {
    method: "POST",
    body: {
      order_id: orderId,
      order_amount: amount,
      order_currency: "INR",
      customer_details: {
        customer_id: status.canteenId,
        customer_name: status.canteenName || user?.name || "Axzen Customer",
        customer_email: process.env.CASHFREE_DEFAULT_EMAIL || "support@axzeninfotech.com",
        customer_phone: String(user?.mobile || "").replace(/\D/g, "").slice(-10) || "9999999999"
      },
      order_meta: {
        return_url: `${returnBase}${String(returnBase).includes("?") ? "&" : "?"}cf_order_id={order_id}`
      },
      order_note: `${status.planName} ${selected.label} recharge`
    }
  });
  await saveSubscriptionOrder({
    orderId,
    canteenId: status.canteenId,
    marketingCanteenId: status.marketingCanteenId,
    canteenName: status.canteenName,
    planName: status.planName,
    months: selected.months,
    amount,
    status: "created",
    paymentSessionId: order.payment_session_id || "",
    cfOrderId: order.cf_order_id || "",
    oldExpiryDate: status.expiryDate,
    createdByMobile: user?.mobile || ""
  });
  return { ...status, orderId, amount, months: selected.months, paymentSessionId: order.payment_session_id || "", environment: CASHFREE_ENV };
}

async function verifySubscriptionCashfreeOrder(orderId, actor = {}) {
  const order = await findSubscriptionOrder(orderId);
  if (!order) throw new Error("Recharge order not found");
  if (order.status === "paid" && order.newExpiryDate) return order;
  const payments = await cashfreeRequest(`/orders/${encodeURIComponent(orderId)}/payments`);
  const rows = Array.isArray(payments) ? payments : (payments.payments || payments.data || []);
  const successPayment = rows.find(item => String(item.payment_status || item.status || "").toUpperCase() === "SUCCESS");
  if (!successPayment) {
    await saveSubscriptionOrder({ ...order, status: "pending", rawPayment: rows });
    throw new Error("Payment not completed yet");
  }
  const oldExpiry = order.oldExpiryDate || (await subscriptionStatusForCanteen(order.canteenId)).expiryDate;
  const startFrom = oldExpiry && !isPastDate(oldExpiry) ? `${oldExpiry}T00:00:00+05:30` : new Date();
  const newExpiryDate = addMonthsDate(order.months, startFrom);
  await saveSubscriptionOrder({
    ...order,
    status: "paid",
    paymentStatus: "SUCCESS",
    cfPaymentId: successPayment.cf_payment_id || successPayment.payment_id || "",
    paymentMode: successPayment.payment_group || successPayment.payment_method || "Cashfree",
    newExpiryDate,
    rawPayment: successPayment
  });
  const marketing = (await allMarketingCanteens()).find(item => normalizeCanteenId(item.activatedCanteenId) === normalizeCanteenId(order.canteenId));
  if (marketing) {
    const paidAmount = Number(marketing.paidAmount || 0) + Number(order.amount || 0);
    await updateMarketingCanteen(marketing.id, {
      status: "Active",
      planType: "Paid",
      selectedPlan: order.planName || marketing.selectedPlan || "Professional",
      planStartDate: new Date().toISOString().slice(0, 10),
      planExpiryDate: newExpiryDate,
      paidAmount,
      pendingAmount: 0,
      paymentMode: "Cashfree",
      blocked: false,
      online: true
    }, actor);
    await addMarketingPayment({
      canteenId: marketing.id,
      canteenName: marketing.canteenName,
      amount: order.amount,
      pendingAmount: 0,
      paymentMode: "Cashfree",
      collectedBy: "SELF_RECHARGE",
      collectedByName: "App Recharge"
    });
    await addMarketingActivity({ type: "payment", text: `${marketing.canteenName} recharged ${order.months} months`, actor: "Cashfree", canteenId: marketing.id });
  }
  await Canteen.updateOne(
    { canteenId: normalizeCanteenId(order.canteenId) },
    { $set: { active: true, paymentStatus: "paid", paymentReference: orderId, plan: order.planName || "Professional" } }
  ).catch(() => {});
  return findSubscriptionOrder(orderId);
}

function normalizeWebsitePlan(payload, existing = {}) {
  const features = Array.isArray(payload.features)
    ? payload.features
    : String(payload.features || "").split(/\r?\n|,/);
  return {
    id: Number(payload.id || existing.id || Date.now()),
    name: String(payload.name ?? existing.name ?? "").trim(),
    description: String(payload.description ?? existing.description ?? "").trim(),
    originalPrice: String(payload.originalPrice ?? existing.originalPrice ?? "").trim(),
    offerPrice: String(payload.offerPrice ?? existing.offerPrice ?? "").trim(),
    billingCycle: String(payload.billingCycle ?? existing.billingCycle ?? "month").trim(),
    badge: String(payload.badge ?? existing.badge ?? "").trim(),
    cta: String(payload.cta ?? existing.cta ?? "").trim(),
    popular: payload.popular === true || payload.popular === "true",
    active: payload.active === false || payload.active === "false" ? false : true,
    sortOrder: Number(payload.sortOrder ?? existing.sortOrder ?? existing.id ?? 1),
    features: features.map(item => String(item || "").trim()).filter(Boolean)
  };
}

async function saveWebsitePlan(payload, actor) {
  const existing = (await allWebsitePlans()).find(item => Number(item.id) === Number(payload.id)) || {};
  const plan = normalizeWebsitePlan(payload, existing);
  if (!plan.name || !plan.offerPrice) throw new Error("Plan name and price are required");
  if (!plan.cta) plan.cta = `Choose ${plan.name}`;
  if (!plan.features.length) plan.features = ["POS Billing", "Reports", "Support"];
  if (!mongoReady) {
    const index = memory.websitePlans.findIndex(item => Number(item.id) === Number(plan.id));
    if (index >= 0) memory.websitePlans[index] = { ...memory.websitePlans[index], ...plan };
    else memory.websitePlans.push(plan);
  } else {
    await WebsitePlan.findOneAndUpdate({ id: plan.id }, { $set: plan }, { upsert: true, new: true });
  }
  await addMarketingActivity({
    type: "pricing",
    text: `${plan.name} website plan updated`,
    actor: actor?.name || "Super Admin"
  });
  return plan;
}

async function saveEnquiry(payload) {
  const name = String(payload.name || "").trim();
  const phone = String(payload.phone || "").trim();
  const plan = String(payload.plan || "").trim();
  if (!name || !phone || !plan) {
    throw new Error("Name, phone number and plan are required");
  }
  const entry = {
    id: Number(payload.id || Date.now()),
    name,
    phone,
    email: String(payload.email || "").trim(),
    plan,
    message: String(payload.message || "").trim(),
    source: String(payload.source || "pos.axzen.in").trim(),
    status: String(payload.status || "New").trim(),
    assignedTo: String(payload.assignedTo || "").trim(),
    notes: String(payload.notes || "").trim()
  };
  if (!mongoReady) {
    memory.enquiries.unshift({ ...entry, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    return memory.enquiries[0];
  }
  return Enquiry.create(entry);
}

async function updateEnquiry(id, patch, actor) {
  const allowed = {};
  ["status", "assignedTo", "notes"].forEach(key => {
    if (Object.prototype.hasOwnProperty.call(patch, key)) allowed[key] = String(patch[key] || "").trim();
  });
  if (Object.keys(allowed).length === 0) throw new Error("No enquiry update supplied");
  if (!mongoReady) {
    const index = memory.enquiries.findIndex(item => String(item._id || item.id) === String(id));
    if (index === -1) throw new Error("Enquiry not found");
    memory.enquiries[index] = { ...memory.enquiries[index], ...allowed, updatedAt: new Date().toISOString() };
    return memory.enquiries[index];
  }
  const query = mongoose.Types.ObjectId.isValid(String(id)) ? { _id: id } : { id: Number(id) };
  const saved = await Enquiry.findOneAndUpdate(query, { $set: allowed }, { new: true }).lean();
  if (!saved) throw new Error("Enquiry not found");
  await addMarketingActivity({
    type: "enquiry",
    text: `${saved.name || "Website enquiry"} marked ${saved.status || "updated"}`,
    actor: actor?.name || "Super Admin"
  });
  return saved;
}

async function allPrinters() {
  if (!mongoReady) return memory.printers;
  return Printer.find({}).sort({ createdAt: -1 }).lean();
}

function printerStatusLabel(value) {
  const status = String(value || "Stock").trim();
  if (["With Executive", "Executive", "Assigned"].includes(status)) return "With Executive";
  if (["Allotted", "Installed", "Canteen"].includes(status)) return "Allotted";
  return "Stock";
}

async function savePrinterInventory(payload, actor) {
  const serialNumber = String(payload.serialNumber || "").trim().toUpperCase();
  if (!serialNumber) throw new Error("Printer serial number is required");
  const existingPrinter = await findPrinterBySerial(serialNumber) || {};
  const nextStatus = printerStatusLabel(payload.status ?? existingPrinter.status ?? "Stock");
  const printer = {
    provider: String(payload.provider ?? existingPrinter.provider ?? "Thermal Printer").trim(),
    model: String(payload.model ?? existingPrinter.model ?? payload.provider ?? "Thermal Printer").trim(),
    serialNumber,
    bluetoothName: String(payload.bluetoothName ?? existingPrinter.bluetoothName ?? "").trim(),
    macAddress: String(payload.macAddress ?? existingPrinter.macAddress ?? "").trim(),
    status: nextStatus,
    allottedTo: String(payload.allottedTo ?? existingPrinter.allottedTo ?? "").trim(),
    allottedToName: String(payload.allottedToName ?? existingPrinter.allottedToName ?? "").trim(),
    marketingCanteenId: Number(payload.marketingCanteenId ?? existingPrinter.marketingCanteenId ?? 0) || undefined,
    marketingCanteenName: String(payload.marketingCanteenName ?? existingPrinter.marketingCanteenName ?? "").trim(),
    installedBy: existingPrinter.installedBy || actor?.employeeId || actor?.name || "",
    installedAt: existingPrinter.installedAt || new Date().toISOString()
  };
  if (printer.status === "Stock") {
    printer.allottedTo = "";
    printer.allottedToName = "";
    printer.marketingCanteenId = undefined;
    printer.marketingCanteenName = "";
  }
  if (printer.status === "With Executive") {
    if (!printer.allottedTo) throw new Error("Select sales executive for printer allocation");
    printer.marketingCanteenId = undefined;
    printer.marketingCanteenName = "";
  }
  if (printer.status === "Allotted") {
    if (!printer.allottedTo) throw new Error("Printer must be assigned to a sales executive before canteen allotment");
    if (!printer.marketingCanteenId || !printer.marketingCanteenName) throw new Error("Select canteen for printer allotment");
  }
  if (!mongoReady) {
    const existing = memory.printers.find(item => String(item.serialNumber || "").toUpperCase() === serialNumber);
    if (existing) Object.assign(existing, printer);
    else memory.printers.unshift({ id: Date.now(), ...printer });
    return existing || memory.printers[0];
  }
  return Printer.findOneAndUpdate({ serialNumber }, { $set: printer }, { new: true, upsert: true }).lean();
}

async function findPrinterBySerial(serialNumber) {
  const serial = String(serialNumber || "").trim().toUpperCase();
  if (!serial) return null;
  return (await allPrinters()).find(item => String(item.serialNumber || "").toUpperCase() === serial) || null;
}

async function validatePrinterForMarketingCanteen(canteen, user) {
  if (Number(canteen.printersRequired || 0) <= 0) return null;
  if (!canteen.printerModel || !canteen.printerSerialNumber) {
    throw new Error("Select one allotted printer for this canteen");
  }
  const printer = await findPrinterBySerial(canteen.printerSerialNumber);
  if (!printer || String(printer.model || "") !== canteen.printerModel) {
    throw new Error("Selected printer serial number does not match printer model");
  }
  if (printerStatusLabel(printer.status) !== "With Executive" || String(printer.allottedTo || "") !== String(user.employeeId || "")) {
    throw new Error("This printer is not available in your allotted printer list");
  }
  return printer;
}

function normalizeMarketingCanteen(payload, user) {
  const planStartDate = String(payload.planStartDate || new Date().toISOString().slice(0, 10));
  const businessCategory = String(payload.businessCategory || payload.category || payload.businessType || "Canteen").trim() || "Canteen";
  return {
    dineInRequested: payload.dineInRequested === true,
    id: Number(payload.id || Date.now()),
    canteenName: String(payload.canteenName || "").trim(),
    businessCategory,
    ownerName: String(payload.ownerName || "").trim(),
    ownerMobile: String(payload.ownerMobile || "").trim(),
    alternateMobile: String(payload.alternateMobile || "").trim(),
    address: String(payload.address || "").trim(),
    city: String(payload.city || "").trim(),
    state: String(payload.state || "").trim(),
    counters: Number(payload.counters || 1),
    printersRequired: Number(payload.requestedPrinters ?? payload.printersRequired ?? 0),
    printerModel: String(payload.printerModel || "").trim(),
    printerSerialNumber: String(payload.printerSerialNumber || "").trim().toUpperCase(),
    selectedPlan: String(payload.selectedPlan || "Starter"),
    planType: String(payload.planType || "Trial"),
    planStartDate,
    planExpiryDate: planExpiryFromPayload(payload, { planStartDate }),
    demoDays: Number(payload.demoDays || payload.trialDays || 0),
    requestedDemoDays: Number(payload.demoDays || payload.trialDays || 0),
    paymentMode: String(payload.paymentMode || "Cash"),
    paidAmount: Number(payload.paidAmount || 0),
    pendingAmount: Number(payload.pendingAmount || 0),
    commissionAmount: Number(payload.commissionAmount || 0),
    menuSetupItems: Array.isArray(payload.menuSetupItems) ? payload.menuSetupItems : [],
    notes: String(payload.notes || ""),
    documents: String(payload.documents || ""),
    status: "Pending Approval",
    online: false,
    blocked: false,
    printersAssigned: 0,
    submittedBy: user.employeeId,
    submittedByName: user.name,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
}

async function createMarketingCanteen(payload, user) {
  const canteen = normalizeMarketingCanteen(payload, user);
  if (!canteen.canteenName || !canteen.ownerName || !canteen.ownerMobile) {
    throw new Error("Canteen name, owner name, and owner mobile are required");
  }
  if (!mongoReady) memory.marketingCanteens.unshift(canteen);
  else await MarketingCanteen.create(canteen);
  await addMarketingPayment({
    canteenId: canteen.id,
    canteenName: canteen.canteenName,
    amount: canteen.paidAmount,
    pendingAmount: canteen.pendingAmount,
    paymentMode: canteen.paymentMode,
    collectedBy: user.employeeId,
    collectedByName: user.name
  });
  await addMarketingActivity({
    type: "created",
    text: `${canteen.canteenName} submitted for approval`,
    actor: user.name,
    canteenId: canteen.id
  });
  return canteen;
}

async function updateMarketingCanteen(id, patch, actor) {
  const next = { ...patch, updatedAt: new Date().toISOString() };
  if (!mongoReady) {
    const index = memory.marketingCanteens.findIndex(item => Number(item.id) === Number(id));
    if (index === -1) throw new Error("Canteen not found");
    memory.marketingCanteens[index] = { ...memory.marketingCanteens[index], ...next };
    return memory.marketingCanteens[index];
  }
  const saved = await MarketingCanteen.findOneAndUpdate({ id: Number(id) }, { $set: next }, { new: true }).lean();
  if (!saved) throw new Error("Canteen not found");
  return saved;
}

function marketingCredentialSeed(canteen) {
  const id = String(canteen.id || Date.now()).replace(/\D/g, "").slice(-6).padStart(4, "0");
  return {
    activatedCanteenId: canteen.activatedCanteenId || `AXC-${id}`,
    canteenLoginId: canteen.canteenLoginId || `AXC${id}`,
    defaultPassword: canteen.defaultPassword || `AXZEN${id}`
  };
}

async function activateApprovedCanteen(canteen, actor) {
  const credentials = marketingCredentialSeed(canteen);
  const coreCanteen = {
    canteenId: credentials.activatedCanteenId,
    name: canteen.canteenName,
    businessCategory: canteen.businessCategory || "Canteen",
    ownerName: canteen.ownerName,
    phone: canteen.ownerMobile,
    address: [canteen.address, canteen.city, canteen.state].filter(Boolean).join(", "),
    plan: canteen.selectedPlan,
    paymentStatus: Number(canteen.pendingAmount || 0) > 0 ? "pending" : "paid",
    paymentReference: canteen.paymentMode,
    active: true,
    createdByMarketingUser: canteen.submittedBy
  };

  if (!mongoReady) {
    const index = memory.canteens.findIndex(item => item.canteenId === coreCanteen.canteenId);
    if (index >= 0) memory.canteens[index] = { ...memory.canteens[index], ...coreCanteen };
    else memory.canteens.push(coreCanteen);
  } else {
    await Canteen.findOneAndUpdate(
      { canteenId: coreCanteen.canteenId },
      { $set: coreCanteen },
      { upsert: true, new: true }
    );
  }

  await saveUser({
    canteenId: credentials.activatedCanteenId,
    name: canteen.ownerName || `${canteen.canteenName} Admin`,
    mobile: credentials.canteenLoginId,
    password: credentials.defaultPassword,
    role: "admin",
    active: true,
    mustChangePassword: true
  });
  await seedCanteenDefaults(credentials.activatedCanteenId, canteen.canteenName, canteen.businessCategory || "Canteen");
  const setupItems = Array.isArray(canteen.menuSetupItems) ? canteen.menuSetupItems : [];
  for (const [index, item] of setupItems.entries()) {
    const name = String(item?.name || "").trim();
    if (!name) continue;
    const category = String(item.category || inferMenuCategory(name, canteen.businessCategory)).trim() || "Snacks";
    const eggItem = name.toLowerCase().includes("egg");
    const billingType = String(item.billingType || "").toLowerCase() === "weight" || (shopKindFromCategory(canteen.businessCategory) === "chicken" && !eggItem && isChickenLikeItem({ name, category }))
      ? "weight"
      : "quantity";
    const nextItem = {
      canteenId: credentials.activatedCanteenId,
      name,
      price: Number(item.price || 0),
      category,
      billingType,
      unit: String(item.unit || (billingType === "weight" ? "Kgs" : "Plate")),
      image: String(item.image || ""),
      sortOrder: 1000 + index
    };
    if (!itemFitsBusinessCategory(nextItem, canteen.businessCategory || "Canteen")) continue;
    await saveMenuItem(nextItem);
  }
  if (canteen.printerSerialNumber) {
    await savePrinterInventory({
      serialNumber: canteen.printerSerialNumber,
      model: canteen.printerModel,
      status: "Allotted",
      allottedTo: canteen.submittedBy,
      allottedToName: canteen.submittedByName,
      marketingCanteenId: canteen.id,
      marketingCanteenName: canteen.canteenName
    }, actor);
  }

  return updateMarketingCanteen(canteen.id, credentials, actor);
}

async function reconcileApprovedCanteens() {
  const canteens = await allMarketingCanteens();
  const approved = canteens.filter(item =>
    item.status === "Active" ||
    item.status === "Trial" ||
    item.activatedCanteenId ||
    item.canteenLoginId
  );
  for (const canteen of approved) {
    await activateApprovedCanteen(canteen, { name: "System", employeeId: "SYSTEM" });
  }
}

function isToday(dateValue) {
  const date = new Date(dateValue || Date.now());
  const today = new Date();
  return date.toDateString() === today.toDateString();
}

function marketingSummary(canteens, users, activities, payments = [], supportTickets = [], enquiries = [], printers = []) {
  const active = canteens.filter(item => item.status === "Active");
  const trial = canteens.filter(item => item.status === "Trial");
  const expired = canteens.filter(item => item.status === "Expired" || (item.planExpiryDate && new Date(item.planExpiryDate) < new Date() && item.status !== "Blocked" && item.status !== "Trial" && item.status !== "Active"));
  const blocked = canteens.filter(item => item.status === "Blocked" || item.blocked);
  const pendingPayments = canteens.reduce((sum, item) => sum + Number(item.pendingAmount || 0), 0);
  const visibleIds = new Set(canteens.map(item => Number(item.id)));
  const visiblePayments = payments.filter(item => visibleIds.has(Number(item.canteenId)));
  const monthlyRevenue = visiblePayments
    .filter(item => new Date(item.createdAt || Date.now()).getMonth() === new Date().getMonth())
    .reduce((sum, item) => sum + Number(item.amount || 0), 0);
  const printersAssigned = printers.filter(item => printerStatusLabel(item.status) === "Allotted").length;
  const printersAvailable = printers.filter(item => printerStatusLabel(item.status) !== "Allotted").length;
  const onlineRecentMs = 2 * 60 * 1000;
  const onlineCanteens = canteens.filter(item => item.lastSeenAt && Date.now() - new Date(item.lastSeenAt).getTime() <= onlineRecentMs);
  const performance = users.filter(user => user.role === "marketing").map(user => {
    const mine = canteens.filter(item => item.submittedBy === user.employeeId);
    return {
      employeeId: user.employeeId,
      name: user.name,
      registrations: mine.length,
      approved: mine.filter(item => item.status === "Active" || item.status === "Trial").length,
      rejected: mine.filter(item => item.status === "Rejected").length,
      collection: mine.reduce((sum, item) => sum + Number(item.paidAmount || 0), 0),
      pending: mine.reduce((sum, item) => sum + Number(item.pendingAmount || 0), 0),
      target: Number(user.target || 0)
    };
  });
  return {
    cards: {
      totalCanteens: canteens.length,
      activeCanteens: active.length,
      trialCanteens: trial.length,
      expiredCanteens: expired.length,
      blockedCanteens: blocked.length,
      onlineCanteens: onlineCanteens.length,
      offlineCanteens: Math.max(0, canteens.length - onlineCanteens.length),
      todaysRegistrations: canteens.filter(item => isToday(item.createdAt)).length,
      todaysCollections: visiblePayments.filter(item => isToday(item.createdAt)).reduce((sum, item) => sum + Number(item.amount || 0), 0),
      monthlyRevenue,
      pendingPayments,
      printersAssigned,
      printersAvailable,
      openSupportTickets: supportTickets.filter(item => ["Open", "Pending"].includes(item.status)).length,
      totalEnquiries: enquiries.length,
      newEnquiries: enquiries.filter(item => ["new", "New"].includes(String(item.status || "New"))).length,
      pendingInstallations: canteens.filter(item => ["Active", "Trial"].includes(item.status) && Number(item.printersAssigned || 0) < Number(item.printersRequired || 0)).length
    },
    marketingPerformance: performance,
    recentActivities: activities.slice(0, 12)
  };
}

async function sendReportNow(reason = "manual", canteenId = DEFAULT_CANTEEN_ID) {
  const appSettings = await getSettings(canteenId);
  const to = appSettings.adminWhatsAppNumber || appSettings.reportPhone;
  if (!to) throw new Error("Missing admin WhatsApp number");

  const message = await buildWhatsAppReport(appSettings.reportType || "daily", canteenId);
  const meta = await sendWhatsAppText(to, message);
  await addWhatsAppLog({ canteenId, success: true, reason, to, message, meta });
  return { to, message, meta };
}

async function checkScheduledWhatsAppReport() {
  try {
    const appSettings = await getSettings();
    if (!appSettings.autoReport) return { checked: true, sent: false, reason: "auto report off" };

    const scheduleTime = parseReportTime(appSettings.reportTime);
    const nowTime = indiaTimeKey();
    const todayKey = indiaDateKey();
    const reportKey = `${todayKey}-${scheduleTime}-${appSettings.reportType || "daily"}`;
    if (nowTime !== scheduleTime) return { checked: true, sent: false, reason: "not scheduled time" };
    if (lastScheduledReportKey === reportKey) return { checked: true, sent: false, reason: "already sent" };

    const result = await sendReportNow("scheduled");
    lastScheduledReportKey = reportKey;
    return { checked: true, sent: true, to: result.to };
  } catch (error) {
    const appSettings = await getSettings();
    await addWhatsAppLog({
      canteenId: DEFAULT_CANTEEN_ID,
      success: false,
      reason: "scheduled",
      to: appSettings.adminWhatsAppNumber || appSettings.reportPhone || "",
      error: error.message
    });
    return { checked: true, sent: false, error: error.message };
  }
}

async function dashboardData(canteenId = DEFAULT_CANTEEN_ID) {
  const [
    orders,
    stock,
    stockUsage,
    expenses,
    products,
    creditors,
    addresses,
    allUserRows,
    settings
  ] = await Promise.all([
    allOrders(canteenId),
    allStockItems(canteenId),
    allStockUsage(canteenId),
    allExpenses(canteenId),
    allMenuItems(canteenId, { includeHidden: true }),
    allCreditors(canteenId),
    allBranchAddresses(canteenId),
    allUsers(),
    getSettings(canteenId)
  ]);
  const todayOrders = reportOrdersForType(orders, "daily");
  const todayTotals = paymentTotals(todayOrders);
  const totalExpenses = expenses.reduce((sum, expense) => sum + Number(expense.amount || 0), 0);

  return {
    ...todayTotals,
    totalBills: todayOrders.length,
    totalExpenses,
    netCollection: todayTotals.totalSales - totalExpenses,
    topItems: topItemsFromOrders(todayOrders),
    userSales: userSalesFromOrders(todayOrders),
    lowStock: stock.filter(item => Number(item.stock || 0) <= Number(item.minStock || 0)),
    stock,
    stockUsage,
    expenses,
    products,
    creditors,
    addresses,
    users: allUserRows.filter(user => normalizeCanteenId(user.canteenId || DEFAULT_CANTEEN_ID) === normalizeCanteenId(canteenId)).map(publicUser),
    settings,
    orders
  };
}

// Extract WhatsApp messages, statuses, contacts, and errors from a Meta Cloud API webhook payload.
async function handleWhatsAppWebhook(payload) {
  try {
    const entries = Array.isArray(payload && payload.entry) ? payload.entry : [];

    for (const entry of entries) {
      const changes = Array.isArray(entry && entry.changes) ? entry.changes : [];

      for (const change of changes) {
        const value = change && change.value ? change.value : {};
        const contacts = Array.isArray(value.contacts) ? value.contacts : [];
        const messages = Array.isArray(value.messages) ? value.messages : [];
        const statuses = Array.isArray(value.statuses) ? value.statuses : [];
        const errors = Array.isArray(value.errors) ? value.errors : [];

        // Log contact details when Meta includes profile/contact information.
        contacts.forEach(contact => {
          console.log("WhatsApp contact:", {
            waId: contact.wa_id || "",
            name: contact.profile && contact.profile.name ? contact.profile.name : ""
          });
        });

        // Log each incoming WhatsApp message without assuming a fixed message shape.
        messages.forEach(message => {
          const senderPhone = message.from || "";
          const messageId = message.id || "";
          const messageType = message.type || "";
          const timestamp = message.timestamp || "";

          console.log("WhatsApp message event:", {
            senderPhone,
            messageId,
            messageType,
            timestamp
          });

          if (messageType === "text") {
            const text = message.text && message.text.body ? message.text.body : "";
            console.log(`Incoming WhatsApp message from ${senderPhone}: ${text}`);
          }
        });

        // Log delivery, read, sent, and failed statuses from Meta status webhooks.
        for (const status of statuses) {
          const deliveryStatus = status.status === "delivered" ? status.status : "";
          const readStatus = status.status === "read" ? status.status : "";
          const failedStatus = status.status === "failed" ? status.status : "";
          const statusErrors = Array.isArray(status.errors) ? status.errors : [];
          const errorText = statusErrors.map(item =>
            item.message || item.title || item.error_data?.details || item.code || "Unknown status error"
          ).join(" | ");

          console.log("WhatsApp status event:", {
            recipientPhone: status.recipient_id || "",
            messageId: status.id || "",
            timestamp: status.timestamp || "",
            status: status.status || "",
            deliveryStatus,
            readStatus,
            failedStatus,
            errors: statusErrors
          });

          await addWhatsAppLog({
            success: status.status !== "failed",
            reason: `status:${status.status || "unknown"}`,
            to: status.recipient_id || "",
            error: errorText,
            meta: status
          });
        }

        // Log webhook-level errors if Meta sends an error array in the change value.
        for (const error of errors) {
          console.log("WhatsApp webhook error:", {
            code: error.code || "",
            title: error.title || "",
            message: error.message || "",
            details: error.error_data && error.error_data.details ? error.error_data.details : ""
          });

          await addWhatsAppLog({
            success: false,
            reason: "webhook:error",
            to: "",
            error: error.message || error.title || error.error_data?.details || "WhatsApp webhook error",
            meta: error
          });
        }
      }
    }
  } catch (error) {
    console.warn("WhatsApp webhook payload handling failed:", error.message);
  }
}

// Register Meta WhatsApp Cloud API webhook verification and event receiver routes.
function registerWhatsAppWebhookRoutes(targetApp) {
  targetApp.get("/webhook", (req, res) => {
    const mode = req.query["hub.mode"];
    const token = req.query["hub.verify_token"];
    const challenge = req.query["hub.challenge"];

    if (!VERIFY_TOKEN) {
      console.warn("VERIFY_TOKEN is missing. Rejecting Meta webhook verification.");
    }

    if (mode === "subscribe" && token === VERIFY_TOKEN) {
      console.log("Meta WhatsApp webhook verified successfully.");
      return res.status(200).send(challenge);
    }

    console.warn("Meta WhatsApp webhook verification failed.");
    return res.sendStatus(403);
  });

  targetApp.post("/webhook", (req, res) => {
    const payload = req.body || {};

    console.log("Meta WhatsApp webhook payload:", JSON.stringify(payload, null, 2));
    res.sendStatus(200);

    setImmediate(() => {
      handleWhatsAppWebhook(payload).catch(error => {
        console.warn("WhatsApp webhook async handler failed:", error.message);
      });
    });
  });
}

registerWhatsAppWebhookRoutes(app);

app.get("/", (req, res) => {
  res.redirect("/admin/");
});

app.get("/health", (req, res) => {
  res.json({ success: true, mongoReady, database: DB_NAME, mongoError });
});

app.get("/products", requireCanteenAuth, async (req, res) => {
  const canteenId = req.authUser.canteenId || DEFAULT_CANTEEN_ID;
  const settings = await getSettings(canteenId);
  await sanitizeMenuForBusinessCategory(canteenId, settings.businessCategory, settings.posMode);
  res.json(await allMenuItems(canteenId));
});

app.get("/catalog/default-products", requireAdmin, async (req, res) => {
  const liveNames = new Set((await allMenuItems(req.authUser.canteenId, { includeHidden: true })).map(item => String(item.name || "").trim().toLowerCase()));
  res.json(defaultCatalogItems.map(item => ({ ...item, active: liveNames.has(String(item.name || "").trim().toLowerCase()) })));
});

app.get("/catalog/all-items", requireAdmin, async (req, res) => {
  res.json(await allCatalogItemsForCanteen(req.authUser.canteenId, req.query.q));
});

app.get("/catalog/item-suggestions", requireAdmin, async (req, res) => {
  res.json(await globalItemSuggestions(req.query.q, req.authUser.canteenId));
});

app.post("/products", requireDatabase, requireAdmin, async (req, res) => {
  try {
    const product = await saveMenuItem({ ...req.body, canteenId: req.authUser.canteenId || DEFAULT_CANTEEN_ID });
    res.json({ success: true, product, products: await allMenuItems(req.authUser.canteenId, { includeHidden: true }) });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.delete("/products/:id", requireDatabase, requireAdmin, async (req, res) => {
  await deleteMenuItem(req.params.id, req.authUser.canteenId);
  res.json({ success: true, products: await allMenuItems(req.authUser.canteenId, { includeHidden: true }) });
});

app.get("/creditors", requireCanteenAuth, async (req, res) => {
  res.json(await allCreditors(req.authUser.canteenId));
});

app.post("/creditors", requireDatabase, requireAdmin, async (req, res) => {
  try {
    const creditor = await saveCreditor({ ...req.body, canteenId: req.authUser.canteenId || DEFAULT_CANTEEN_ID });
    res.json({ success: true, creditor, creditors: await allCreditors(req.authUser.canteenId) });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.get("/stock", requireCanteenAuth, async (req, res) => {
  res.json(await allStockItems(req.authUser.canteenId));
});

app.post("/stock", requireDatabase, requireStockAccess, async (req, res) => {
  try {
    const item = await saveStockItem({ ...req.body, canteenId: req.authUser.canteenId || DEFAULT_CANTEEN_ID });
    res.json({ success: true, item, stock: await allStockItems(req.authUser.canteenId) });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.get("/stock-usage", requireCanteenAuth, async (req, res) => {
  res.json(await allStockUsage(req.authUser.canteenId));
});

app.post("/stock-usage", requireDatabase, requireStockAccess, async (req, res) => {
  try {
    const usage = await saveStockUsage({ ...req.body, canteenId: req.authUser.canteenId || DEFAULT_CANTEEN_ID }, req.authUser);
    res.json({ success: true, usage, stock: await allStockItems(req.authUser.canteenId), stockUsage: await allStockUsage(req.authUser.canteenId) });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.get("/expenses", requireAdmin, async (req, res) => res.json(await allExpenses(req.authUser.canteenId)));

app.post("/expenses", requireDatabase, requireAdmin, async (req, res) => {
  try {
    const expense = await saveExpense({ ...req.body, canteenId: req.authUser.canteenId || DEFAULT_CANTEEN_ID });
    res.json({ success: true, expense, expenses: await allExpenses(req.authUser.canteenId) });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.get("/settings", async (req, res) => {
  const authUser = canteenUserFromRequest(req);
  res.json(await getSettings(authUser?.canteenId || DEFAULT_CANTEEN_ID));
});

app.post("/settings", requireDatabase, requireAdmin, async (req, res) => {
  try {
    res.json({ success: true, settings: await saveSettings(req.body, req.authUser.canteenId) });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.post("/login", requireDatabase, async (req, res) => {
  const loginId = normalizeMobile(req.body.loginId || req.body.mobile || req.body.restaurantId || req.body.canteenId);
  const mobile = normalizeMobile(req.body.mobile || req.body.loginId);
  const canteenHint = normalizeCanteenId(req.body.canteenId || req.body.restaurantId || "");
  const loginAsCanteenId = normalizeCanteenId(loginId);
  const compactCanteenId = value => normalizeCanteenId(value).replace(/[^A-Z0-9]/g, "");
  const password = String(req.body.password || "");
  const users = (await allUsers()).filter(item => item.active !== false && String(item.password) === password);
  const matches = users.filter(item => {
    const itemCanteenId = normalizeCanteenId(item.canteenId || DEFAULT_CANTEEN_ID);
    const itemMobile = normalizeMobile(item.mobile);
    const canteenOk = !canteenHint || compactCanteenId(itemCanteenId) === compactCanteenId(canteenHint);
    return canteenOk && (itemMobile === loginId || itemMobile === mobile || (loginAsCanteenId && compactCanteenId(itemCanteenId) === compactCanteenId(loginAsCanteenId)));
  });

  const mobileMatches = matches.filter(item => normalizeMobile(item.mobile) === loginId || normalizeMobile(item.mobile) === mobile);
  const uniqueCanteens = new Set(mobileMatches.map(item => normalizeCanteenId(item.canteenId || DEFAULT_CANTEEN_ID)));
  if (!canteenHint && mobileMatches.length > 1 && uniqueCanteens.size > 1 && compactCanteenId(loginAsCanteenId) !== compactCanteenId(matches[0]?.canteenId)) {
    return res.status(409).json({ success: false, message: "Restaurant ID required for this mobile number" });
  }

  const allowedMatches = [];
  let blockedMessage = "Invalid credentials or inactive canteen";
  for (const item of matches) {
    const access = await canteenAccessStatus(item.canteenId || DEFAULT_CANTEEN_ID);
    if (access.allowed) allowedMatches.push(item);
    else if (access.message) blockedMessage = access.message;
  }
  const user = allowedMatches.find(item => compactCanteenId(item.canteenId || DEFAULT_CANTEEN_ID) === compactCanteenId(loginAsCanteenId)) || allowedMatches[0];

  if (!user) return res.status(401).json({ success: false, message: blockedMessage });
  const canteen = await getCoreCanteen(user.canteenId);
  const subscription = await subscriptionStatusForCanteen(user.canteenId);
  const canteenWithPrinter = {
    ...canteen,
    printerModel: subscription.printerModel || canteen?.printerModel || "",
    printerSerialNumber: subscription.printerSerialNumber || canteen?.printerSerialNumber || ""
  };
  res.json({ success: true, user: { ...publicUser(user), canteen: canteenWithPrinter }, token: signToken(user), settings: await getSettings(user.canteenId) });
});

app.post("/activate-owner", requireDatabase, requireAdmin, async (req, res) => {
  try {
    const canteenId = normalizeCanteenId(req.authUser.canteenId || DEFAULT_CANTEEN_ID);
    const canteen = await getCoreCanteen(canteenId);
    const mobile = normalizeMobile(req.body.mobile);
    const password = String(req.body.password || "");
    const name = String(req.body.name || canteen?.ownerName || "Owner").trim() || "Owner";
    const registeredPhone = normalizeMobile(canteen?.phone || "");
    if (!mobile || !password || password.length < 4) {
      return res.status(400).json({ success: false, message: "Mobile and new password are required" });
    }
    if (registeredPhone && mobile !== registeredPhone) {
      return res.status(400).json({ success: false, message: "Registered mobile number does not match" });
    }
    const owner = await saveUser({
      canteenId,
      name,
      mobile,
      password,
      role: "admin",
      active: true,
      mustChangePassword: false
    });
    const tempMobile = normalizeMobile(req.authUser.mobile);
    if (tempMobile && tempMobile !== mobile) {
      if (!mongoReady) {
        const temp = memory.users.find(user =>
          normalizeCanteenId(user.canteenId || DEFAULT_CANTEEN_ID) === canteenId &&
          normalizeMobile(user.mobile) === tempMobile
        );
        if (temp) temp.active = false;
      } else {
        await User.updateOne({ canteenId, mobile: tempMobile }, { $set: { active: false } });
      }
    }
    const savedUser = publicUser(owner);
    res.json({ success: true, user: { ...savedUser, canteen }, token: signToken(owner), settings: await getSettings(canteenId) });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message || "Owner activation failed" });
  }
});

app.post("/forgot-password", requireDatabase, async (req, res) => {
  try {
    const mobile = normalizeMobile(req.body.mobile);
    const password = String(req.body.password || req.body.newPassword || "");
    const canteenHint = normalizeCanteenId(req.body.canteenId || req.body.restaurantId || "");
    if (!mobile || password.length < 4) {
      return res.status(400).json({ success: false, message: "Mobile and new password are required" });
    }
    const users = (await allUsers()).filter(user => {
      const sameMobile = normalizeMobile(user.mobile) === mobile;
      const sameCanteen = !canteenHint || normalizeCanteenId(user.canteenId || DEFAULT_CANTEEN_ID) === canteenHint;
      return user.active !== false && sameMobile && sameCanteen;
    });
    const uniqueCanteens = new Set(users.map(user => normalizeCanteenId(user.canteenId || DEFAULT_CANTEEN_ID)));
    if (!users.length) {
      return res.status(404).json({ success: false, message: "Mobile number not found" });
    }
    if (!canteenHint && uniqueCanteens.size > 1) {
      return res.status(409).json({ success: false, message: "Restaurant ID required for this mobile number" });
    }
    const target = users.find(user => user.role === "admin") || users[0];
    const updated = await saveUser({ ...target, password, mustChangePassword: false, active: true });
    const canteen = await getCoreCanteen(updated.canteenId);
    res.json({ success: true, message: "Password updated", user: publicUser(updated), canteenId: updated.canteenId, canteen });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message || "Password reset failed" });
  }
});

app.get("/users", requireCanteenAuth, async (req, res) => {
  const canteenId = normalizeCanteenId(req.authUser.canteenId || DEFAULT_CANTEEN_ID);
  res.json((await allUsers()).filter(user => normalizeCanteenId(user.canteenId || DEFAULT_CANTEEN_ID) === canteenId).map(publicUser));
});

app.post("/users", requireDatabase, requireAdmin, async (req, res) => {
  try {
    const payload = {
      ...req.body,
      canteenId: req.authUser.canteenId || DEFAULT_CANTEEN_ID,
      mustChangePassword: req.body.mustChangePassword === true
    };
    res.json({ success: true, user: publicUser(await saveUser(payload)) });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.delete("/users/:mobile", requireDatabase, requireAdmin, async (req, res) => {
  await deleteUser(req.params.mobile, req.authUser.canteenId);
  res.json({ success: true });
});

app.get("/addresses", requireCanteenAuth, async (req, res) => {
  res.json(await allBranchAddresses(req.authUser.canteenId));
});

app.post("/addresses", requireDatabase, requireAdmin, async (req, res) => {
  try {
    const address = await saveBranchAddress({ ...req.body, canteenId: req.authUser.canteenId || DEFAULT_CANTEEN_ID });
    res.json({ success: true, address, addresses: await allBranchAddresses(req.authUser.canteenId) });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

const dineService = require("./dine-in").registerDineIn({ app, mongoose, requireDatabase, requireCanteenAuth,
  requireAdmin, requireSuperAdmin, MarketingCanteen, allMenuItems, getSettings,
  saveOrder: payload => saveOrder(payload, true) });

app.post("/orders", requireDatabase, requireCanteenAuth, async (req, res) => {
  try {
    const order = await saveOrder({ ...req.body, canteenId: req.authUser.canteenId || DEFAULT_CANTEEN_ID });
    io.emit("new-order", order);
    res.json({ success: true, order });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.post("/orders/sync", requireDatabase, requireCanteenAuth, async (req, res) => {
  try {
    const incoming = Array.isArray(req.body.orders) ? req.body.orders : [];
    const synced = [];
    for (const payload of incoming) {
      const order = await saveOrder({ ...payload, canteenId: req.authUser.canteenId || DEFAULT_CANTEEN_ID });
      synced.push(order.clientOrderId || order.id);
    }
    if (synced.length) io.emit("orders-synced", synced);
    res.json({ success: true, synced });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.get("/orders", requireCanteenAuth, async (req, res) => res.json(await allOrders(req.authUser.canteenId)));

app.delete("/orders", requireDatabase, requireAdmin, async (req, res) => {
  await clearOrders(req.authUser.canteenId);
  io.emit("orders-cleared");
  res.json({ success: true });
});

app.delete("/orders/:id", requireDatabase, requireAdmin, async (req, res) => {
  await deleteOrder(req.params.id, req.authUser.canteenId);
  io.emit("order-deleted", req.params.id);
  res.json({ success: true });
});

app.get("/dashboard", requireCanteenAuth, async (req, res) => res.json(await dashboardData(req.authUser.canteenId)));

app.get("/subscription/status", requireDatabase, requireCanteenTokenOnly, async (req, res) => {
  try {
    res.json({ success: true, ...(await subscriptionStatusForCanteen(req.authUser.canteenId)) });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message || "Subscription status failed" });
  }
});

app.post("/subscription/recharge/create-order", requireDatabase, requireCanteenTokenOnly, async (req, res) => {
  try {
    const result = await createSubscriptionCashfreeOrder(req.authUser.canteenId, req.body.months, req.authUser, req, String(req.body.planName || "").trim());
    res.json({ success: true, ...result });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message || "Recharge order failed" });
  }
});

app.post("/subscription/recharge/verify", requireDatabase, requireCanteenTokenOnly, async (req, res) => {
  try {
    const order = await verifySubscriptionCashfreeOrder(String(req.body.orderId || ""), req.authUser);
    res.json({ success: true, order, subscription: await subscriptionStatusForCanteen(req.authUser.canteenId) });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message || "Payment verification failed" });
  }
});

async function handleCashfreeSubscriptionWebhook(req, res) {
  try {
    const orderId = cashfreeWebhookOrderId(req.body);
    const signature = String(req.headers["x-webhook-signature"] || "");
    const timestamp = String(req.headers["x-webhook-timestamp"] || "");
    if (!orderId && (!signature || !timestamp)) {
      return res.json({ success: true, message: "Cashfree webhook endpoint ready" });
    }
    verifyCashfreeWebhookSignature(req);
    if (!orderId) return res.json({ success: true, ignored: true, message: "Cashfree test event received" });
    const paymentStatus = cashfreeWebhookPaymentStatus(req.body);
    if (!paymentStatus.includes("SUCCESS") && !paymentStatus.includes("PAID")) {
      const order = await findSubscriptionOrder(orderId);
      if (order) await saveSubscriptionOrder({ ...order, status: "pending", rawPayment: req.body });
      return res.json({ success: true, ignored: true, orderId, paymentStatus });
    }
    const order = await verifySubscriptionCashfreeOrder(orderId, { name: "Cashfree Webhook", mobile: "WEBHOOK" });
    return res.json({ success: true, orderId, status: order?.status || "paid" });
  } catch (error) {
    console.warn("Cashfree webhook failed:", error.message);
    return res.status(400).json({ success: false, message: error.message });
  }
}

app.post("/cashfree/webhook", requireDatabase, handleCashfreeSubscriptionWebhook);
app.post("/subscription/recharge/webhook", requireDatabase, handleCashfreeSubscriptionWebhook);

app.get("/api/website-plans", requireDatabase, async (req, res) => {
  res.json({ success: true, plans: await allWebsitePlans({ activeOnly: true }) });
});

app.post("/api/enquiry", requireDatabase, async (req, res) => {
  try {
    const enquiry = await saveEnquiry(req.body || {});
    res.status(201).json({ success: true, message: "Your enquiry has been submitted successfully.", enquiryId: enquiry._id || enquiry.id });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.get("/help/problems", requireCanteenAuth, (req, res) => {
  res.json({ success: true, problems: HELP_PROBLEMS, supportPhone: SALES_CONTACT_PHONE });
});

app.get("/help/tickets", requireCanteenAuth, async (req, res) => {
  res.json({ success: true, tickets: await helpTicketsForCanteen(req.authUser.canteenId) });
});

app.post("/help/tickets", requireDatabase, requireCanteenAuth, async (req, res) => {
  try {
    const canteenId = normalizeCanteenId(req.authUser.canteenId || DEFAULT_CANTEEN_ID);
    const appSettings = await getSettings(canteenId);
    const ticket = normalizeHelpSubmission(req.body, {
      canteenId,
      canteenName: appSettings.canteenName || req.authUser.canteenName,
      submittedByLogin: req.authUser.loginId || req.authUser.mobile || req.authUser.name
    });
    const saved = await MarketingSupportTicket.create({ id: Date.now(), ...ticket });
    res.status(201).json({ success: true, message: "Help request submitted.", ticket: saved });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.get("/app-update/manifest", requireDatabase, requireCanteenAuth, async (req, res) => {
  res.setHeader("Cache-Control", "private, no-store");
  const canteenId = normalizeCanteenId(req.authUser.canteenId || DEFAULT_CANTEEN_ID);
  const canteen = await MarketingCanteen.findOne({ activatedCanteenId: canteenId }).lean();
  if (!canteen?.appReleaseId) return res.status(204).end();
  const release = await AppRelease.findOne({ _id: canteen.appReleaseId, status: "Published" }).select("-bundle").lean();
  if (!release) return res.status(204).end();
  res.json({ success: true, release: { id: String(release._id), version: release.version, notes: release.notes || "", sha256: release.sha256, signature: release.signature, size: release.size, downloadUrl: `/app-update/bundles/${release._id}` } });
});

app.get("/app-update/bundles/:id", requireDatabase, requireCanteenAuth, async (req, res) => {
  const canteenId = normalizeCanteenId(req.authUser.canteenId || DEFAULT_CANTEEN_ID);
  const canteen = await MarketingCanteen.findOne({ activatedCanteenId: canteenId }).lean();
  if (!canteen || String(canteen.appReleaseId || "") !== String(req.params.id)) return res.status(403).json({ success: false, message: "Release is not assigned to this canteen" });
  const release = await AppRelease.findOne({ _id: req.params.id, status: "Published" }).lean();
  if (!release?.bundle) return res.status(404).json({ success: false, message: "Release bundle not found" });
  const raw = release.bundle;
  const bundle = Buffer.isBuffer(raw) ? raw : Buffer.from(raw.buffer || raw);
  res.setHeader("Content-Type", "application/zip");
  res.setHeader("Content-Length", bundle.length);
  res.setHeader("Cache-Control", "private, no-store");
  res.send(bundle);
});

app.post("/marketing-api/login", requireDatabase, async (req, res) => {
  const employeeId = String(req.body.employeeId || req.body.mobile || "").trim();
  const password = String(req.body.password || "");
  const loginDigits = employeeId.replace(/\D/g, "");
  const user = (await allMarketingUsers()).find(item => {
    if (item.active === false || String(item.password) !== password) return false;
    if (String(item.employeeId).toLowerCase() === employeeId.toLowerCase()) return true;
    const mobileDigits = String(item.mobile || "").replace(/\D/g, "");
    return loginDigits.length >= 10 && mobileDigits.length >= 10 && (mobileDigits === loginDigits || mobileDigits.endsWith(loginDigits) || loginDigits.endsWith(mobileDigits));
  });
  if (!user) return res.status(401).json({ success: false, message: "Invalid employee ID, phone or password" });
  res.json({ success: true, user: publicMarketingUser(user), token: signMarketingToken(user) });
});

app.get("/marketing-api/me", requireMarketingAuth, async (req, res) => {
  res.json({ success: true, user: req.marketingUser });
});

app.put("/marketing-api/me/bank", requireDatabase, requireMarketingAuth, async (req, res) => {
  try {
    const user = await saveMarketingUser({
      employeeId: req.marketingUser.employeeId,
      bankAccountName: req.body.bankAccountName,
      bankAccountNumber: req.body.bankAccountNumber,
      bankIfsc: req.body.bankIfsc,
      bankUpi: req.body.bankUpi
    }, req.marketingUser);
    res.json({ success: true, user: publicMarketingUser(user) });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message || "Bank details save failed" });
  }
});

app.get("/marketing-api/dashboard", requireMarketingAuth, async (req, res) => {
  const allCanteens = await allMarketingCanteens();
  const users = await allMarketingUsers();
  const activities = await allMarketingActivities();
  const payments = await allMarketingPayments();
  const supportTickets = await allMarketingSupportTickets();
  const enquiries = await allEnquiries();
  const websitePlans = await allWebsitePlans();
  const printers = await allPrinters();
  const appReleases = await allAppReleases();
  const isAdmin = req.marketingUser.role === "super_admin" || req.marketingUser.role === "manager";
  const canteens = isAdmin
    ? allCanteens
    : allCanteens.filter(item => item.submittedBy === req.marketingUser.employeeId);
  const visibleIds = new Set(canteens.map(item => Number(item.id)));
  const visibleUsers = isAdmin
    ? users
    : users.filter(item => item.employeeId === req.marketingUser.employeeId);
  const visiblePayments = isAdmin
    ? payments
    : payments.filter(item => visibleIds.has(Number(item.canteenId)));
  const helpDesk = req.marketingUser.department === "Help Center";
  const visibleSupportTickets = (isAdmin || helpDesk)
    ? supportTickets
    : supportTickets.filter(item => canteens.some(canteen =>
        normalizeCanteenId(canteen.activatedCanteenId) === normalizeCanteenId(item.canteenId) ||
        canteen.canteenName === item.canteenName
      ));
  const enrichedSupportTickets = visibleSupportTickets.map(ticket => {
    const canteen = allCanteens.find(item =>
      normalizeCanteenId(item.activatedCanteenId) === normalizeCanteenId(ticket.canteenId) ||
      item.canteenName === ticket.canteenName
    );
    return { ...ticket, canteen: canteen ? {
      activatedCanteenId: canteen.activatedCanteenId,
      canteenName: canteen.canteenName,
      businessCategory: canteen.businessCategory,
      ownerName: canteen.ownerName,
      ownerMobile: canteen.ownerMobile,
      city: canteen.city,
      address: canteen.address
    } : null };
  });
  const visibleEnquiries = isAdmin ? enquiries : [];
  const visiblePrinters = isAdmin
    ? printers
    : printers.filter(item =>
        item.allottedTo === req.marketingUser.employeeId ||
        visibleIds.has(Number(item.marketingCanteenId))
      );
  const deskOnly = helpDesk && !isAdmin;
  res.json({
    success: true,
    canteens: deskOnly ? [] : canteens,
    users: (deskOnly ? visibleUsers.filter(item => item.employeeId === req.marketingUser.employeeId) : visibleUsers).map(publicMarketingUser),
    printers: deskOnly ? [] : visiblePrinters,
    payments: deskOnly ? [] : visiblePayments,
    supportTickets: enrichedSupportTickets,
    enquiries: deskOnly ? [] : visibleEnquiries,
    websitePlans: isAdmin && !deskOnly ? websitePlans : [],
    appReleases: isAdmin && !deskOnly ? appReleases : [],
    activities: isAdmin && !deskOnly ? activities : [],
    summary: marketingSummary(deskOnly ? [] : canteens, deskOnly ? [] : visibleUsers, isAdmin && !deskOnly ? activities : [], deskOnly ? [] : visiblePayments, visibleSupportTickets, deskOnly ? [] : visibleEnquiries, deskOnly ? [] : visiblePrinters)
  });
});

app.post("/marketing-api/help-tickets/:id/status", requireDatabase, requireHelpDesk, async (req, res) => {
  try {
    const identifier = String(req.params.id || "").trim();
    const query = mongoose.isValidObjectId(identifier) ? { _id: identifier } : { id: Number(identifier) };
    const patch = {};
    if (req.body.status) {
      const status = normalizeHelpStatus(req.body.status);
      patch.status = status;
      const closed = ["Solved", "Resolved", "Closed"].includes(status);
      patch.resolvedAt = closed ? new Date() : null;
      patch.resolvedBy = closed ? (req.marketingUser.name || req.marketingUser.employeeId) : "";
    }
    if (req.body.priority) {
      const priority = String(req.body.priority || "").trim();
      if (!["Low", "Medium", "High", "Normal"].includes(priority)) throw new Error("Priority must be Low, Medium or High.");
      patch.priority = priority;
    }
    if (Object.prototype.hasOwnProperty.call(req.body, "assignedTo")) patch.assignedTo = String(req.body.assignedTo || "").trim().slice(0, 80);
    const update = {};
    if (Object.keys(patch).length) update.$set = patch;
    const note = String(req.body.note || "").trim().slice(0, 500);
    if (note) update.$push = { comments: { author: req.marketingUser.name || req.marketingUser.employeeId, text: note, createdAt: new Date().toISOString() } };
    const tag = String(req.body.tag || "").trim().slice(0, 30);
    if (tag) update.$addToSet = { tags: tag };
    if (!Object.keys(update).length) throw new Error("Nothing to update.");
    const ticket = await MarketingSupportTicket.findOneAndUpdate(query, update, { new: true }).lean();
    if (!ticket) return res.status(404).json({ success: false, message: "Help request not found" });
    res.json({ success: true, ticket });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.post("/marketing-api/app-releases", requireDatabase, requireSuperAdmin, async (req, res) => {
  try {
    const version = String(req.body.version || "").trim();
    if (!/^[A-Za-z0-9][A-Za-z0-9._-]{0,39}$/.test(version)) throw new Error("Use a valid release version, for example 4.0.1");
    const raw = String(req.body.bundleBase64 || "").replace(/^data:[^,]*;base64,/i, "").replace(/\s+/g, "");
    const bundle = Buffer.from(raw, "base64");
    if (bundle.length < 100 || bundle.length > 6 * 1024 * 1024 || bundle[0] !== 0x50 || bundle[1] !== 0x4b) throw new Error("Upload a valid POS release ZIP smaller than 6 MB");
    if (await AppRelease.exists({ version })) throw new Error("This release version already exists. Use a new version.");
    const sha256 = crypto.createHash("sha256").update(bundle).digest("hex");
    const privateKeyBase64 = process.env.APP_UPDATE_SIGNING_PRIVATE_KEY_BASE64;
    if (!privateKeyBase64) throw new Error("App update signing key is not configured on the backend");
    const privateKey = crypto.createPrivateKey(Buffer.from(privateKeyBase64, "base64").toString("utf8"));
    const signature = crypto.sign("sha256", bundle, privateKey).toString("base64");
    const release = await AppRelease.create({ version, notes: String(req.body.notes || "").trim().slice(0, 500), sha256, signature, size: bundle.length, status: "Draft", bundle, createdBy: req.marketingUser.employeeId });
    res.status(201).json({ success: true, release: { id: String(release._id), version, notes: release.notes, sha256, size: bundle.length, status: release.status } });
  } catch (error) { res.status(400).json({ success: false, message: error.message }); }
});

app.post("/marketing-api/app-releases/:id/publish", requireDatabase, requireSuperAdmin, async (req, res) => {
  try {
    const canteenIds = [...new Set((Array.isArray(req.body.canteenIds) ? req.body.canteenIds : []).map(Number).filter(Number.isFinite))];
    if (!canteenIds.length) throw new Error("Select at least one canteen.");
    const release = await AppRelease.findById(req.params.id).select("-bundle").lean();
    if (!release) throw new Error("Release not found");
    await AppRelease.updateOne({ _id: release._id }, { $set: { status: "Published", publishedAt: new Date() } });
    const result = await MarketingCanteen.updateMany({ id: { $in: canteenIds }, activatedCanteenId: { $nin: [null, ""] } }, { $set: { appReleaseId: String(release._id), appReleaseVersion: release.version } });
    if (!result.modifiedCount) throw new Error("Select approved canteens with an active Canteen ID.");
    await addMarketingActivity({ type: "app_release", text: `POS release ${release.version} published to ${result.modifiedCount} canteen(s)`, actor: req.marketingUser.name });
    res.json({ success: true, message: `Release assigned to ${result.modifiedCount} canteen(s).` });
  } catch (error) { res.status(400).json({ success: false, message: error.message }); }
});

app.post("/marketing-api/website-plans", requireDatabase, requireSuperAdmin, async (req, res) => {
  try {
    const plan = await saveWebsitePlan(req.body || {}, req.marketingUser);
    res.json({ success: true, plan, websitePlans: await allWebsitePlans() });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.post("/marketing-api/enquiries/:id", requireDatabase, requireSuperAdmin, async (req, res) => {
  try {
    const enquiry = await updateEnquiry(req.params.id, req.body || {}, req.marketingUser);
    res.json({ success: true, enquiry, enquiries: await allEnquiries() });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.post("/marketing-api/users", requireDatabase, requireSuperAdmin, async (req, res) => {
  try {
    const employee = await saveMarketingUser(req.body, req.marketingUser);
    res.json({ success: true, user: publicMarketingUser(employee), users: (await allMarketingUsers()).map(publicMarketingUser) });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.post("/marketing-api/users/:employeeId/block", requireDatabase, requireSuperAdmin, async (req, res) => {
  try {
    const active = req.body.blocked === true ? false : req.body.active !== false;
    const employee = await saveMarketingUser({ employeeId: req.params.employeeId, active }, req.marketingUser);
    res.json({ success: true, user: publicMarketingUser(employee), users: (await allMarketingUsers()).map(publicMarketingUser) });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.post("/marketing-api/printers", requireDatabase, requireSuperAdmin, async (req, res) => {
  try {
    const nextStatus = printerStatusLabel(req.body.status);
    const existing = await findPrinterBySerial(req.body.serialNumber);
    const sameExecutive = existing &&
      printerStatusLabel(existing.status) === "With Executive" &&
      String(existing.allottedTo || "") === String(req.body.allottedTo || "");
    if (nextStatus === "With Executive" && existing && printerStatusLabel(existing.status) !== "Stock" && !sameExecutive) {
      return res.status(400).json({ success: false, message: "Only in-stock printers can be assigned to a sales executive" });
    }
    const printer = await savePrinterInventory(req.body, req.marketingUser);
    res.json({ success: true, printer, printers: await allPrinters() });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.post("/marketing-api/canteens", requireDatabase, requireMarketingAuth, async (req, res) => {
  if (req.marketingUser.role !== "marketing") {
    return res.status(403).json({ success: false, message: "Only marketing employees can submit canteens" });
  }
  try {
    const canteen = await createMarketingCanteen(req.body, req.marketingUser);
    res.json({ success: true, canteen });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.post("/marketing-api/canteens/:id/approve", requireDatabase, requireSuperAdmin, async (req, res) => {
  try {
    if (Object.prototype.hasOwnProperty.call(req.body, "dineInEnabled") && typeof req.body.dineInEnabled !== "boolean") throw new Error("Dine In approval must be true or false");
    const before = (await allMarketingCanteens()).find(item => Number(item.id) === Number(req.params.id)) || {};
    const paidAmount = Object.prototype.hasOwnProperty.call(req.body, "paidAmount")
      ? Number(req.body.paidAmount || 0)
      : Number(before.requestedPaidAmount ?? before.paidAmount ?? 0);
    const pendingAmount = Object.prototype.hasOwnProperty.call(req.body, "pendingAmount")
      ? Number(req.body.pendingAmount || 0)
      : Number(before.requestedPendingAmount ?? before.pendingAmount ?? 0);
    const planType = String(req.body.planType || before.planType || (paidAmount > 0 ? "Paid" : "Trial"));
    const status = String(req.body.status || (planType.toLowerCase() === "trial" ? "Trial" : "Active"));
    const planStartDate = String(req.body.planStartDate || before.planStartDate || new Date().toISOString().slice(0, 10));
    const planExpiryDate = planExpiryFromPayload({ ...req.body, planStartDate }, before);
    const approved = await updateMarketingCanteen(req.params.id, {
      status,
      planType,
      selectedPlan: req.body.selectedPlan || before.selectedPlan || "Starter",
      planStartDate,
      planExpiryDate,
      demoDays: Number(req.body.demoDays || before.requestedDemoDays || before.demoDays || 0),
      paidAmount,
      pendingAmount,
      paymentMode: req.body.paymentMode || before.requestedPaymentMode || before.paymentMode || (planType === "Trial" ? "Trial" : "UPI"),
      paymentApprovalStatus: "Approved",
      commissionAmount: Number(req.body.commissionAmount ?? before.commissionAmount ?? 0),
      approvedBy: req.marketingUser.employeeId,
      approvedAt: new Date().toISOString(),
      online: true
    }, req.marketingUser);
    const canteen = await activateApprovedCanteen(approved, req.marketingUser);
    if (typeof req.body.dineInEnabled === "boolean") {
      await dineService.setApproval(canteen.activatedCanteenId, req.body.dineInEnabled, req.marketingUser.employeeId);
    }
    await addMarketingActivity({ type: "approved", text: `${canteen.canteenName} approved and activated`, actor: req.marketingUser.name, canteenId: canteen.id });
    res.json({ success: true, canteen });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.post("/marketing-api/canteens/:id/reject", requireDatabase, requireSuperAdmin, async (req, res) => {
  try {
    const reason = String(req.body.reason || "").trim();
    if (!reason) return res.status(400).json({ success: false, message: "Rejection reason is required" });
    const canteen = await updateMarketingCanteen(req.params.id, { status: "Rejected", rejectionReason: reason, online: false }, req.marketingUser);
    await addMarketingActivity({ type: "rejected", text: `${canteen.canteenName} rejected: ${reason}`, actor: req.marketingUser.name, canteenId: canteen.id });
    res.json({ success: true, canteen });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.post("/marketing-api/canteens/:id/workflow", requireDatabase, requireMarketingAuth, async (req, res) => {
  try {
    const rows = await allMarketingCanteens();
    const current = rows.find(item => Number(item.id) === Number(req.params.id));
    if (!current) return res.status(404).json({ success: false, message: "Lead not found" });
    const isAdminRole = req.marketingUser.role === "super_admin" || req.marketingUser.role === "manager";
    if (!isAdminRole && String(current.submittedBy || "") !== String(req.marketingUser.employeeId || "")) {
      return res.status(403).json({ success: false, message: "You can update only your assigned leads" });
    }
    const activity = {
      id: Date.now(),
      type: String(req.body.type || "Activity").trim(),
      employeeId: req.marketingUser.employeeId,
      employeeName: req.marketingUser.name,
      outcome: String(req.body.outcome || req.body.stage || "").trim(),
      notes: String(req.body.notes || "").trim(),
      followUpDate: String(req.body.followUpDate || "").trim(),
      followUpTime: String(req.body.followUpTime || "").trim(),
      createdAt: new Date().toISOString()
    };
    const nextFollowUp = req.body.nextFollowUp
      || (activity.followUpDate ? `${activity.followUpDate}T${activity.followUpTime || "10:00"}:00+05:30` : current.nextFollowUp || "");
    const timeline = Array.isArray(current.activityTimeline) ? current.activityTimeline : [];
    const followUps = Array.isArray(current.followUps) ? current.followUps : [];
    const nextStage = String(req.body.stage || current.currentStage || current.status || "").trim();
    const printerPatch = {};
    if (String(activity.type || "").toLowerCase().includes("demo started") && Number(current.printersRequired || 0) > 0) {
      const demoCanteen = {
        ...current,
        printerModel: String(req.body.printerModel || current.printerModel || "").trim(),
        printerSerialNumber: String(req.body.printerSerialNumber || current.printerSerialNumber || "").trim().toUpperCase()
      };
      const selectedPrinter = await validatePrinterForMarketingCanteen(demoCanteen, req.marketingUser);
      if (selectedPrinter) {
        await savePrinterInventory({
          serialNumber: selectedPrinter.serialNumber,
          model: selectedPrinter.model,
          status: "Allotted",
          allottedTo: req.marketingUser.employeeId,
          allottedToName: req.marketingUser.name,
          marketingCanteenId: current.id,
          marketingCanteenName: current.canteenName
        }, req.marketingUser);
        printerPatch.printerModel = selectedPrinter.model;
        printerPatch.printerSerialNumber = selectedPrinter.serialNumber;
        printerPatch.printersAssigned = Math.max(1, Number(current.printersAssigned || 0));
      }
    }
    const patch = {
      ...printerPatch,
      currentStage: nextStage || current.currentStage || current.status,
      status: String(req.body.status || nextStage || current.status || "Pending Approval").replace(/_/g, " "),
      nextFollowUp,
      lastActivity: activity,
      activityTimeline: [...timeline, activity]
    };
    if (req.body.selectedPlan) patch.selectedPlan = String(req.body.selectedPlan || current.selectedPlan || "Starter");
    if (req.body.planType) patch.planType = String(req.body.planType || current.planType || "Trial");
    if (req.body.planStartDate) patch.planStartDate = String(req.body.planStartDate);
    if (req.body.planExpiryDate || req.body.trialDays || req.body.demoDays || req.body.planMonths || req.body.months) patch.planExpiryDate = planExpiryFromPayload(req.body, current);
    if (req.body.demoDays || req.body.trialDays) {
      patch.demoDays = Number(req.body.demoDays || req.body.trialDays || current.demoDays || 0);
      patch.requestedDemoDays = patch.demoDays;
    }
    if (Array.isArray(req.body.menuSetupItems)) patch.menuSetupItems = req.body.menuSetupItems;
    if (Object.prototype.hasOwnProperty.call(req.body, "paidAmount")) patch.requestedPaidAmount = Number(req.body.paidAmount || 0);
    if (Object.prototype.hasOwnProperty.call(req.body, "pendingAmount")) patch.requestedPendingAmount = Number(req.body.pendingAmount || 0);
    if (req.body.paymentMode) patch.requestedPaymentMode = String(req.body.paymentMode || "UPI");
    if (req.body.paymentApprovalStatus) {
      patch.paymentApprovalStatus = String(req.body.paymentApprovalStatus);
      patch.paymentApprovalRequestedBy = req.marketingUser.employeeId;
      patch.paymentApprovalRequestedAt = new Date().toISOString();
    }
    if (activity.followUpDate) patch.followUps = [...followUps, { ...activity, status: "Scheduled" }];
    const canteen = await updateMarketingCanteen(req.params.id, patch, req.marketingUser);
    await addMarketingActivity({ type: "lead_workflow", text: `${activity.type} saved for ${current.canteenName}`, actor: req.marketingUser.name, canteenId: current.id });
    res.json({ success: true, canteen });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.post("/marketing-api/canteens/:id/block", requireDatabase, requireSuperAdmin, async (req, res) => {
  try {
    const before = (await allMarketingCanteens()).find(item => Number(item.id) === Number(req.params.id)) || {};
    const blocked = req.body.blocked !== false;
    const restoreStatus = isPastDate(before.planExpiryDate)
      ? "Expired"
      : (before.planType === "Trial" || before.status === "Trial" ? "Trial" : "Active");
    const canteen = await updateMarketingCanteen(req.params.id, {
      status: blocked ? "Blocked" : restoreStatus,
      blocked,
      online: !blocked && restoreStatus !== "Expired"
    }, req.marketingUser);
    if (canteen.activatedCanteenId) {
      await Canteen.findOneAndUpdate(
        { canteenId: normalizeCanteenId(canteen.activatedCanteenId) },
        { $set: { active: !blocked && restoreStatus !== "Expired" } }
      );
    }
    await addMarketingActivity({ type: "blocked", text: `${canteen.canteenName} ${blocked ? "blocked" : "unblocked"}`, actor: req.marketingUser.name, canteenId: canteen.id });
    res.json({ success: true, canteen });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.post("/marketing-api/canteens/:id/payment", requireDatabase, requireSuperAdmin, async (req, res) => {
  try {
    const before = (await allMarketingCanteens()).find(item => Number(item.id) === Number(req.params.id));
    const nextPaidAmount = Number(req.body.paidAmount || 0);
    const paymentDelta = Math.max(0, nextPaidAmount - Number(before?.paidAmount || 0));
    const canteen = await updateMarketingCanteen(req.params.id, {
      paidAmount: nextPaidAmount,
      pendingAmount: Number(req.body.pendingAmount || 0),
      paymentMode: req.body.paymentMode || "UPI",
      selectedPlan: req.body.selectedPlan || before?.selectedPlan || "Professional",
      planType: req.body.planType || (nextPaidAmount > 0 ? "Paid" : before?.planType || "Trial"),
      planStartDate: req.body.planStartDate || before?.planStartDate || new Date().toISOString().slice(0, 10),
      planExpiryDate: planExpiryFromPayload(req.body, before || {}),
      paymentApprovalStatus: "Approved",
      status: req.body.activate === true || nextPaidAmount > 0 ? "Active" : before?.status || "Pending Approval",
      blocked: false,
      online: true
    }, req.marketingUser);
    if (canteen.activatedCanteenId) {
      await Canteen.findOneAndUpdate(
        { canteenId: normalizeCanteenId(canteen.activatedCanteenId) },
        { $set: { active: true, paymentStatus: Number(canteen.pendingAmount || 0) > 0 ? "pending" : "paid", paymentReference: canteen.paymentMode, plan: canteen.selectedPlan || "Professional" } }
      );
    }
    await addMarketingPayment({
      canteenId: canteen.id,
      canteenName: canteen.canteenName,
      amount: paymentDelta || nextPaidAmount,
      pendingAmount: canteen.pendingAmount,
      paymentMode: canteen.paymentMode,
      collectedBy: req.marketingUser.employeeId,
      collectedByName: req.marketingUser.name
    });
    await addMarketingActivity({ type: "payment", text: `${canteen.canteenName} payment updated`, actor: req.marketingUser.name, canteenId: canteen.id });
    res.json({ success: true, canteen });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.post("/marketing-api/canteens/:id/activate-cash-plan", requireDatabase, requireSuperAdmin, async (req, res) => {
  try {
    const before = (await allMarketingCanteens()).find(item => Number(item.id) === Number(req.params.id));
    if (!before) return res.status(404).json({ success: false, message: "Canteen not found" });
    const plans = await allWebsitePlans({ activeOnly: true });
    const cash = normalizeCashPlanActivation(req.body, plans);
    const todayDate = new Date().toISOString().slice(0, 10);
    const startFrom = before.planExpiryDate && !isPastDate(before.planExpiryDate) ? before.planExpiryDate : todayDate;
    const expiryDate = addMonthsDate(cash.months, startFrom);
    let canteen = await updateMarketingCanteen(before.id, {
      status: "Active",
      selectedPlan: cash.planName,
      planType: "Paid",
      planStartDate: todayDate,
      planExpiryDate: expiryDate,
      paidAmount: Number(before.paidAmount || 0) + cash.amount,
      pendingAmount: 0,
      paymentMode: "Cash",
      paymentApprovalStatus: "Approved",
      blocked: false,
      online: true
    }, req.marketingUser);
    if (!canteen.activatedCanteenId) canteen = await activateApprovedCanteen(canteen, req.marketingUser);
    if (canteen.activatedCanteenId) {
      await Canteen.findOneAndUpdate(
        { canteenId: normalizeCanteenId(canteen.activatedCanteenId) },
        { $set: { active: true, paymentStatus: "paid", paymentReference: cash.cashReference || "Cash", plan: cash.planName } }
      );
    }
    const payment = await addMarketingPayment({
      canteenId: canteen.id,
      canteenName: canteen.canteenName,
      amount: cash.amount,
      pendingAmount: 0,
      paymentMode: "Cash",
      paymentReference: cash.cashReference,
      notes: cash.notes,
      collectedBy: req.marketingUser.employeeId,
      collectedByName: req.marketingUser.name
    });
    await addMarketingActivity({ type: "cash_plan", text: `${canteen.canteenName} ${cash.planName} plan activated for ${cash.months} months by cash`, actor: req.marketingUser.name, canteenId: canteen.id });
    res.json({ success: true, message: "Cash received and plan activated.", canteen, payment });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.get("/marketing-api/canteens/:id/takeaway", requireDatabase, requireSuperAdmin, async (req, res) => {
  const customer = await MarketingCanteen.findOne({ id: Number(req.params.id) }).lean();
  if (!customer) return res.status(404).json({ success: false, message: "Organization not found" });
  res.json({ success: true, enabled: customer.takeawayEnabled !== false });
});

app.post("/marketing-api/canteens/:id/takeaway", requireDatabase, requireSuperAdmin, async (req, res) => {
  try {
    if (typeof req.body.enabled !== "boolean") throw new Error("Enabled must be true or false");
    const canteen = await updateMarketingCanteen(req.params.id, { takeawayEnabled: req.body.enabled }, req.marketingUser);
    res.json({ success: true, enabled: canteen.takeawayEnabled !== false });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.post("/marketing-api/canteens/:id/plan", requireDatabase, requireSuperAdmin, async (req, res) => {
  try {
    const before = (await allMarketingCanteens()).find(item => Number(item.id) === Number(req.params.id)) || {};
    const status = req.body.status || "Trial";
    const trialDays = Number(req.body.trialDays || 0);
    const reason = String(req.body.reason || "").trim().slice(0, 300);
    if (status === "Trial" && trialDays > 0 && reason.length < 3) throw new Error("Enter a reason for this trial.");
    const planExpiryDate = planExpiryFromPayload(req.body, before);
    const canteen = await updateMarketingCanteen(req.params.id, {
      status,
      planType: req.body.planType || status,
      selectedPlan: req.body.selectedPlan || "Professional",
      planStartDate: trialDays > 0 ? new Date().toISOString().slice(0, 10) : (req.body.planStartDate || before.planStartDate || new Date().toISOString().slice(0, 10)),
      planExpiryDate,
      ...(reason ? { posTrialReason: reason } : {}),
      blocked: status === "Blocked",
      online: status !== "Expired" && status !== "Blocked"
    }, req.marketingUser);
    if (canteen.activatedCanteenId) {
      await Canteen.findOneAndUpdate(
        { canteenId: normalizeCanteenId(canteen.activatedCanteenId) },
        { $set: { active: status !== "Expired" && status !== "Blocked", plan: canteen.selectedPlan || "Professional" } }
      );
    }
    await addMarketingActivity({ type: "plan", text: `${canteen.canteenName} plan updated${trialDays > 0 ? ` · ${trialDays} day trial` : ""}${reason ? ` · ${reason}` : ""}`, actor: req.marketingUser.name, canteenId: canteen.id });
    res.json({ success: true, canteen });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.post("/marketing-api/canteens/:id/printers", requireDatabase, requireSuperAdmin, async (req, res) => {
  try {
    const canteen = await updateMarketingCanteen(req.params.id, { printersAssigned: Number(req.body.printersAssigned || 0) }, req.marketingUser);
    await addMarketingActivity({ type: "printer", text: `${canteen.canteenName} printers assigned`, actor: req.marketingUser.name, canteenId: canteen.id });
    res.json({ success: true, canteen });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.post("/whatsapp/send-test-report", requireDatabase, requireAdmin, async (req, res) => {
  try {
    const result = await sendReportNow("manual", req.authUser.canteenId);
    res.json({ success: true, to: result.to, message: result.message, meta: result.meta });
  } catch (error) {
    const appSettings = await getSettings(req.authUser.canteenId);
    await addWhatsAppLog({
      canteenId: req.authUser.canteenId,
      success: false,
      reason: "manual",
      to: appSettings.adminWhatsAppNumber || appSettings.reportPhone || "",
      error: error.message
    });
    res.status(500).json({ success: false, message: error.message });
  }
});

app.get("/whatsapp/logs", requireAdmin, async (req, res) => res.json(await allWhatsappLogsForCanteen(req.authUser.canteenId)));

app.get("/whatsapp/status", requireAdmin, async (req, res) => {
  const appSettings = await getSettings(req.authUser.canteenId);
  res.json({
    success: true,
    tokenConfigured: Boolean(process.env.WHATSAPP_TOKEN),
    phoneNumberIdConfigured: Boolean(process.env.WHATSAPP_PHONE_NUMBER_ID),
    apiVersion: process.env.WHATSAPP_API_VERSION || "v25.0",
    recipientConfigured: Boolean(appSettings.adminWhatsAppNumber || appSettings.reportPhone),
    autoReport: Boolean(appSettings.autoReport),
    reportTime: appSettings.reportTime || "22:00",
    reportType: appSettings.reportType || "daily"
  });
});

app.get("/api/cron/whatsapp", async (req, res) => {
  res.json(await checkScheduledWhatsAppReport());
});

io.on("connection", () => {
  console.log("Admin/Mobile connected");
});

async function initializeApp(options = {}) {
  const scheduler = options.scheduler !== false;
  if (!initialized) {
    await connectDatabase();
    initialized = true;
  }
  if (scheduler && !schedulerStarted && process.env.VERCEL !== "1") {
    schedulerStarted = true;
    setInterval(checkScheduledWhatsAppReport, 60 * 1000);
    console.log(`WhatsApp report scheduler running in ${INDIA_TZ} timezone`);
  }
  return app;
}

if (require.main === module) {
  initializeApp({ scheduler: process.env.DISABLE_REPORT_SCHEDULER !== "1" }).finally(() => {
    server.listen(PORT, "0.0.0.0", () => {
      console.log(`axzen Hospitality Backend running on http://localhost:${PORT}`);
    });
  });
}

module.exports = {
  app,
  initializeApp,
  checkScheduledWhatsAppReport,
  handleWhatsAppWebhook,
  registerWhatsAppWebhookRoutes
};
